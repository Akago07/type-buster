export type Difficulty = 'easy' | 'medium' | 'hard';
export type InputMode = 'click' | 'keyboard';
export type GameState = 'setup' | 'playing' | 'victory' | 'defeat';

export interface DifficultyConfig {
  name: Difficulty;
  label: string;
  roundTimeSeconds: number;
  optionCount: number;
  playerDamageOnMiss: number;
  playerDamageOnWrong: number;
  dragonDamageOnHit: number;
  scorePerHit: number;
  badgeColor: string;
}

export interface FloatingCombatText {
  id: string;
  text: string;
  type: 'damage' | 'heal' | 'score' | 'miss' | 'critical';
  x: number;
  y: number;
}

export interface GameStats {
  score: number;
  combo: number;
  maxCombo: number;
  correctAnswers: number;
  wrongAnswers: number;
  missedAnswers: number;
  totalAttempts: number;
  reactionTimes: number[];
  averageReactionTime: number;
  bestReactionTime: number;
  roundsSurvived: number;
}

export type PlayerAction = 'idle' | 'attack' | 'hurt' | 'block';

export interface QTEConfig {
  phase: '50' | '20';
  title: string;
  subtitle: string;
  keys: string[];
  durationSeconds: number;
  damageOnFail: number;
  scoreOnSuccess: number;
}
