import React from 'react';

interface TargetLetterDisplayProps {
  targetLetter: string;
  roundNumber: number;
}

export const TargetLetterDisplay: React.FC<TargetLetterDisplayProps> = ({
  targetLetter,
  roundNumber
}) => {
  return (
    <div
      id="target-display"
      className="relative flex flex-col items-center justify-center p-3 select-none"
    >
      {/* Target Letter Container */}
      <div
        className="relative px-8 py-3 bg-[#110d22]/90 border-2 border-cyan-500/80 rounded-sm flex flex-col items-center justify-center shadow-[0_0_16px_rgba(6,182,212,0.25)]"
      >
        {/* Subtle Category Eyebrow */}
        <span className="font-pixel text-[9px] text-cyan-400 tracking-widest uppercase mb-1">
          REMEMBER
        </span>

        {/* The Target Letter */}
        <div
          id="target-letter"
          className="font-pixel text-5xl sm:text-6xl text-cyan-200 font-black tracking-widest drop-shadow-[0_0_12px_rgba(34,211,238,0.7)] select-none"
        >
          {targetLetter}
        </div>

        {/* Wave Indicator Pill */}
        <div className="absolute -top-2.5 right-2 px-1.5 py-0.5 bg-[#0a0714] border border-cyan-700 font-pixel text-[8px] text-amber-400">
          WAVE {roundNumber}
        </div>
      </div>
    </div>
  );
};
