import React from 'react';
import { GameStats, Difficulty } from '../types';
import { soundManager } from '../audio';

interface VictoryModalProps {
  stats: GameStats;
  difficulty: Difficulty;
  onPlayAgain: () => void;
  onChangeSetup?: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  stats,
  difficulty,
  onPlayAgain,
  onChangeSetup
}) => {
  const accuracy =
    stats.totalAttempts > 0
      ? Math.round((stats.correctAnswers / stats.totalAttempts) * 100)
      : 0;

  return (
    <div
      id="victory-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-[2px] select-none"
    >
      <div className="relative w-full max-w-md bg-[#120f24] border-2 border-amber-400 rounded-sm p-6 flex flex-col items-center shadow-[0_0_30px_rgba(251,191,36,0.3)]">
        {/* Victory Trophy Emblem */}
        <div className="w-12 h-12 bg-amber-400/20 border border-amber-400 flex items-center justify-center mb-3">
          <span className="font-pixel text-xl text-amber-300">★</span>
        </div>

        <h2 className="font-pixel text-lg sm:text-xl text-amber-300 font-black tracking-widest text-center">
          DRAGON SLAYED!
        </h2>
        <p className="font-retro text-sm text-gray-300 text-center mb-4">
          Victory achieved on {difficulty.toUpperCase()} difficulty
        </p>

        {/* Clean Stats Grid */}
        <div className="w-full bg-[#0a0715] p-3.5 border border-[#2d244c] flex flex-col gap-2 font-pixel text-[9px] mb-5">
          <div className="flex justify-between items-center pb-1.5 border-b border-[#211a37]">
            <span className="text-gray-400">FINAL SCORE:</span>
            <span className="text-amber-300 font-bold text-sm">
              {stats.score.toLocaleString()}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">MAX COMBO:</span>
            <span className="text-cyan-300 font-bold">{stats.maxCombo}x</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">ACCURACY:</span>
            <span className="text-emerald-400 font-bold">{accuracy}%</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">BEST REACTION:</span>
            <span className="text-purple-300 font-bold">
              {stats.bestReactionTime < 9999 ? `${stats.bestReactionTime}ms` : '--'}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">WAVES SURVIVED:</span>
            <span className="text-yellow-300 font-bold">{stats.roundsSurvived}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          <button
            type="button"
            id="play-again-victory-btn"
            onClick={() => {
              soundManager.playButtonClick();
              onPlayAgain();
            }}
            className="pixel-btn pixel-btn-gold py-2.5 px-6 text-xs font-bold w-full tracking-wider"
          >
            PLAY AGAIN
          </button>

          {onChangeSetup && (
            <button
              type="button"
              id="change-setup-victory-btn"
              onClick={() => {
                soundManager.playButtonClick();
                onChangeSetup();
              }}
              className="pixel-btn py-2 px-6 text-[10px] text-gray-300 bg-[#1e1736] border-[#362b5a] w-full"
            >
              CHANGE SETUP
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

