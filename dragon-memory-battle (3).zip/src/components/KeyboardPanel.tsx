import React from 'react';

interface KeyboardPanelProps {
  targetLetter: string;
  lastKey: string | null;
  isKeyPressed: boolean;
}

export const KeyboardPanel: React.FC<KeyboardPanelProps> = ({
  targetLetter,
  lastKey,
  isKeyPressed
}) => {
  return (
    <div
      id="keyboard-panel"
      className="w-full max-w-xl mx-auto flex items-center justify-between px-3 py-1.5 bg-[#120e24] border border-[#2d254b] rounded-sm select-none"
    >
      <div className="flex items-center gap-2">
        <span className="w-1.5 h-1.5 bg-emerald-400 inline-block" />
        <span className="font-pixel text-[8px] text-gray-300">
          KEYBOARD MODE
        </span>
      </div>

      <div className="flex items-center gap-3 font-pixel text-[8px]">
        <div className="flex items-center gap-1">
          <span className="text-gray-400">TARGET:</span>
          <span className="text-cyan-300 font-bold px-1.5 py-0.5 bg-[#0a0715] border border-cyan-800">
            {targetLetter}
          </span>
        </div>

        <div className="flex items-center gap-1">
          <span className="text-gray-400">PRESSED:</span>
          <span
            id="last-key-pressed"
            className={`font-bold px-1.5 py-0.5 border ${
              isKeyPressed
                ? 'bg-amber-500 text-black border-amber-300'
                : 'bg-[#0a0715] text-gray-300 border-[#282142]'
            }`}
          >
            {lastKey ? lastKey.toUpperCase() : '-'}
          </span>
        </div>
      </div>
    </div>
  );
};
