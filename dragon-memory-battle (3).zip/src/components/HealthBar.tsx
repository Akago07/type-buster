import React from 'react';

interface HealthBarProps {
  type: 'player' | 'dragon';
  currentHp: number;
  maxHp: number;
  label?: string;
}

export const HealthBar: React.FC<HealthBarProps> = ({
  type,
  currentHp,
  maxHp,
  label
}) => {
  const percentage = Math.max(0, Math.min(100, (currentHp / maxHp) * 100));
  const isPlayer = type === 'player';

  // Danger state (<= 30%), Warning state (<= 50%)
  const isDanger = percentage <= 30;
  const isWarning = percentage > 30 && percentage <= 50;

  const barId = isPlayer ? 'player-hp-bar' : 'dragon-hp-bar';
  const fillId = isPlayer ? 'player-hp-fill' : 'dragon-hp-fill';
  const textId = isPlayer ? 'player-hp-text' : 'dragon-hp-text';

  const defaultLabel = isPlayer ? 'PLAYER' : 'DRAGON';
  const displayLabel = label || defaultLabel;

  return (
    <div
      id={barId}
      className={`relative w-full flex flex-col p-2 bg-[#120e22] border-2 ${
        isPlayer ? 'border-[#0284c7]' : 'border-[#e11d48]'
      } rounded-sm transition-all select-none ${
        isDanger ? 'danger' : isWarning ? 'warning' : ''
      }`}
      style={{
        boxShadow: '0 2px 0 0 #000, inset 0 0 0 1px rgba(255,255,255,0.05)'
      }}
    >
      {/* Label and Numbers */}
      <div className="flex justify-between items-center mb-1 font-pixel text-[9px] sm:text-[10px]">
        <div className="flex items-center gap-1.5">
          <span
            className={`w-2 h-2 inline-block ${
              isPlayer
                ? isDanger
                  ? 'bg-rose-500 animate-ping'
                  : 'bg-cyan-400'
                : isDanger
                ? 'bg-amber-400 animate-ping'
                : 'bg-rose-500'
            }`}
          />
          <span
            className={`tracking-wider font-bold ${
              isPlayer ? 'text-cyan-300' : 'text-rose-300'
            }`}
          >
            {displayLabel}
          </span>
        </div>

        <span
          id={textId}
          className={`font-mono font-bold tracking-wider ${
            isDanger
              ? 'text-rose-400 animate-pulse'
              : isWarning
              ? 'text-amber-300'
              : 'text-gray-200'
          }`}
        >
          {Math.round(currentHp)} / {maxHp}
        </span>
      </div>

      {/* Sleek Bar Outer Frame */}
      <div className="relative h-4 sm:h-5 w-full bg-[#080612] border border-black overflow-hidden rounded-xs">
        {/* Animated Delayed Damage Ghost Bar */}
        <div
          className="absolute inset-y-0 left-0 bg-amber-500/40 transition-all duration-500 ease-out"
          style={{ width: `${percentage}%` }}
        />

        {/* Main HP Fill */}
        <div
          id={fillId}
          className={`relative h-full transition-all duration-300 ease-out ${
            isPlayer
              ? isDanger
                ? 'bg-gradient-to-r from-red-600 to-rose-400'
                : isWarning
                ? 'bg-gradient-to-r from-amber-600 to-yellow-400'
                : 'bg-gradient-to-r from-cyan-600 via-teal-500 to-emerald-400'
              : isDanger
              ? 'bg-gradient-to-r from-purple-700 via-rose-600 to-amber-500'
              : 'bg-gradient-to-r from-red-700 via-rose-600 to-orange-500'
          }`}
          style={{ width: `${percentage}%` }}
        >
          {/* Subtle top shine */}
          <div className="absolute top-0 inset-x-0 h-0.5 bg-white/40" />
        </div>

        {/* Clean segment lines */}
        <div className="absolute inset-0 flex pointer-events-none">
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              className="h-full border-r border-black/50 flex-1"
            />
          ))}
          <div className="flex-1" />
        </div>
      </div>
    </div>
  );
};
