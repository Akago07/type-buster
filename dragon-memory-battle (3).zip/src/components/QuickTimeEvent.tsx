import React, { useState, useEffect, useRef } from 'react';
import { QTEConfig } from '../types';
import { soundManager } from '../audio';

interface QuickTimeEventProps {
  config: QTEConfig;
  onSuccess: () => void;
  onFail: () => void;
}

export const QuickTimeEvent: React.FC<QuickTimeEventProps> = ({
  config,
  onSuccess,
  onFail
}) => {
  const [pressedKeys, setPressedKeys] = useState<Set<string>>(new Set());
  const [timeLeft, setTimeLeft] = useState<number>(config.durationSeconds);
  const [outcome, setOutcome] = useState<'pending' | 'success' | 'fail'>('pending');

  const pressedKeysRef = useRef<Set<string>>(new Set());
  const outcomeRef = useRef<'pending' | 'success' | 'fail'>('pending');

  // Keep refs synced to avoid closure issues in key listeners
  outcomeRef.current = outcome;
  pressedKeysRef.current = pressedKeys;

  // Sound cue on QTE trigger
  useEffect(() => {
    soundManager.playQTEAlert();
  }, []);

  // Timer loop
  useEffect(() => {
    if (outcome !== 'pending') return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        const next = Math.max(0, prev - 0.05);

        if (next <= 0) {
          clearInterval(interval);
          if (outcomeRef.current === 'pending') {
            setOutcome('fail');
            outcomeRef.current = 'fail';
            soundManager.playWrongSound();
            soundManager.playDragonAttack();
            setTimeout(() => {
              onFail();
            }, 1000);
          }
          return 0;
        }
        return next;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [outcome, onFail]);

  // Keyboard Event Listeners for Simultaneous Key Tracking
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (outcomeRef.current !== 'pending') return;

      const key = e.key.toUpperCase();
      if (!config.keys.includes(key)) return;

      e.preventDefault();

      const current = new Set(pressedKeysRef.current);
      if (!current.has(key)) {
        current.add(key);
        setPressedKeys(new Set(current));
        soundManager.playButtonClick();

        // Check if ALL required keys are simultaneously held
        const allPressed = config.keys.every((k) => current.has(k));
        if (allPressed && outcomeRef.current === 'pending') {
          setOutcome('success');
          outcomeRef.current = 'success';
          soundManager.playShieldBlock();
          soundManager.playCorrectSound();
          setTimeout(() => {
            onSuccess();
          }, 1000);
        }
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (outcomeRef.current !== 'pending') return;

      const key = e.key.toUpperCase();
      if (!config.keys.includes(key)) return;

      const current = new Set(pressedKeysRef.current);
      if (current.has(key)) {
        current.delete(key);
        setPressedKeys(new Set(current));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [config.keys, onSuccess]);

  const percentage = Math.max(0, Math.min(100, (timeLeft / config.durationSeconds) * 100));

  return (
    <div
      id="qte-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-[2px] select-none"
    >
      <div
        className={`relative w-full max-w-md p-5 sm:p-6 flex flex-col items-center text-center transition-all ${
          outcome === 'success'
            ? 'bg-[#081b24] border-4 border-cyan-400 pixel-box-cyan'
            : outcome === 'fail'
            ? 'bg-[#22070d] border-4 border-rose-600 pixel-box-red'
            : 'bg-[#150d24] border-4 border-amber-500 pixel-box-gold'
        }`}
      >
        {/* Warning Indicator Header */}
        <div className="flex items-center gap-2 mb-2">
          <span className="font-pixel text-xs sm:text-sm text-rose-500 animate-pulse">
            ⚠ DANGER ⚠
          </span>
        </div>

        {/* Action Title */}
        <h2 className="font-pixel text-lg sm:text-xl text-amber-300 font-black tracking-wider drop-shadow-[0_2px_0_#000]">
          {config.title}
        </h2>
        <p className="font-retro text-sm text-gray-300 mt-1 mb-4">
          {config.subtitle}
        </p>

        {/* Keycaps Visual Display */}
        <div className="w-full bg-[#0a0713] p-4 border-2 border-black flex flex-col items-center gap-3">
          <div className="font-pixel text-[9px] text-gray-400 tracking-wider">
            HOLD SIMULTANEOUSLY:
          </div>

          <div className="flex items-center justify-center gap-3 sm:gap-4 flex-wrap">
            {config.keys.map((key, idx) => {
              const isHeld = pressedKeys.has(key);
              const isComboSuccess = outcome === 'success';

              return (
                <div key={key} className="flex items-center gap-2">
                  <div
                    className={`pixel-keycap w-14 h-14 sm:w-16 sm:h-16 text-xl sm:text-2xl font-bold transition-all ${
                      isComboSuccess
                        ? 'bg-emerald-600 text-white border-emerald-300 pressed scale-105'
                        : isHeld
                        ? 'bg-amber-500 text-black border-amber-300 pressed scale-105'
                        : 'bg-[#1c172e] text-cyan-300'
                    }`}
                  >
                    {key}
                  </div>
                  {idx < config.keys.length - 1 && (
                    <span className="font-pixel text-xs text-amber-400 font-black">
                      +
                    </span>
                  )}
                </div>
              );
            })}
          </div>

          {/* Held status indicator */}
          <div className="font-pixel text-[8px] text-gray-400 mt-1">
            {config.keys.filter((k) => pressedKeys.has(k)).length} / {config.keys.length} KEYS HELD
          </div>
        </div>

        {/* Timer Bar */}
        <div className="w-full mt-4 flex flex-col gap-1">
          <div className="flex justify-between items-center font-pixel text-[9px]">
            <span className="text-gray-300">DODGE TIME:</span>
            <span className="text-amber-400 font-mono font-bold">
              {timeLeft.toFixed(2)}s
            </span>
          </div>

          <div className="relative h-4 w-full bg-[#090612] border-2 border-black overflow-hidden">
            <div
              className={`h-full transition-all duration-75 ease-linear ${
                percentage > 50
                  ? 'bg-gradient-to-r from-cyan-500 to-emerald-400'
                  : percentage > 25
                  ? 'bg-gradient-to-r from-amber-500 to-yellow-400'
                  : 'bg-gradient-to-r from-rose-600 to-red-500 animate-pulse'
              }`}
              style={{ width: `${percentage}%` }}
            />
          </div>
        </div>

        {/* Outcome Banner */}
        {outcome === 'success' && (
          <div className="mt-4 font-pixel text-sm sm:text-base text-cyan-300 font-black tracking-widest animate-bounce">
            ★ BLOCKED! PERFECT DEFLECTION! ★
          </div>
        )}

        {outcome === 'fail' && (
          <div className="mt-4 font-pixel text-sm sm:text-base text-rose-500 font-black tracking-widest animate-pulse">
            ✖ TOO SLOW! DRAGON STRUCK! ✖
          </div>
        )}
      </div>
    </div>
  );
};
