import React from 'react';

interface AnswerButtonsProps {
  options: string[];
  onSelectOption: (letter: string) => void;
  disabled?: boolean;
  selectedLetter: string | null;
  feedbackState: { [key: string]: 'correct' | 'wrong' | null };
}

export const AnswerButtons: React.FC<AnswerButtonsProps> = ({
  options,
  onSelectOption,
  disabled = false,
  feedbackState
}) => {
  return (
    <div
      id="answer-buttons"
      className="w-full max-w-xl mx-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 sm:gap-3 p-1 select-none"
    >
      {options.map((letter, index) => {
        const feedback = feedbackState[letter];
        const isCorrect = feedback === 'correct';
        const isWrong = feedback === 'wrong';

        return (
          <button
            key={`${letter}-${index}`}
            id={`btn-option-${letter}`}
            type="button"
            disabled={disabled}
            onClick={() => onSelectOption(letter)}
            className={`pixel-btn relative h-14 sm:h-16 w-full flex items-center justify-center font-pixel text-xl sm:text-2xl font-bold tracking-wider rounded-xs transition-all focus:outline-none focus:ring-1 focus:ring-cyan-400 ${
              isCorrect
                ? 'correct'
                : isWrong
                ? 'wrong'
                : 'bg-[#1b1532] text-gray-100 hover:bg-[#282046] border-[#372d5c]'
            }`}
            style={{
              boxShadow: isCorrect
                ? '0 0 12px #10b981'
                : isWrong
                ? '0 0 12px #ef4444'
                : '0 2px 0 0 #000'
            }}
          >
            {/* Letter Glyph */}
            <span className="relative z-10 drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]">
              {letter}
            </span>

            {/* Keyboard shortcut hint */}
            <span className="absolute bottom-1 right-1.5 font-pixel text-[8px] text-gray-400/60">
              [{letter}]
            </span>
          </button>
        );
      })}
    </div>
  );
};
