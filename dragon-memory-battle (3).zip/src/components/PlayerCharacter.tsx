import React from 'react';
import { PlayerAction } from '../types';

interface PlayerCharacterProps {
  action: PlayerAction;
  hp: number;
  maxHp: number;
}

export const PlayerCharacter: React.FC<PlayerCharacterProps> = ({
  action,
  hp,
  maxHp
}) => {
  const isLowHp = hp <= maxHp * 0.3;

  return (
    <div
      id="player-character"
      className="relative flex flex-col items-center select-none"
    >
      {/* Green Turf & Soil Pedestal for Player */}
      <div className="absolute -bottom-3 w-32 sm:w-44 h-8 flex flex-col items-center z-0">
        {/* Grass Tuft Top Layer */}
        <div className="w-full h-3 bg-[#22c55e] rounded-t-full border-t border-[#86efac] shadow-[0_2px_8px_rgba(22,101,52,0.6)]" />
        {/* Deep Soil Base */}
        <div className="w-28 sm:w-36 h-4 bg-[#14532d] rounded-b-md border-b-2 border-[#052e16]" />
        {/* Decorative Grass Spikes */}
        <div className="absolute -top-1 inset-x-2 flex justify-around">
          <div className="w-1.5 h-2.5 bg-[#4ade80] rotate-[-12deg]" />
          <div className="w-1.5 h-3 bg-[#22c55e]" />
          <div className="w-1.5 h-2.5 bg-[#86efac] rotate-[15deg]" />
          <div className="w-1.5 h-2 bg-[#22c55e] rotate-[-8deg]" />
        </div>
      </div>

      {/* Main Character Sprite Box */}
      <div
        className={`relative z-10 w-32 sm:w-40 md:w-44 h-40 sm:h-48 md:h-52 transition-transform ${
          action === 'attack'
            ? 'player-attack'
            : action === 'hurt'
            ? 'player-hurt'
            : action === 'block'
            ? 'player-block'
            : 'player-idle'
        } ${isLowHp ? 'warning' : ''}`}
      >
        <svg
          viewBox="0 0 96 112"
          className="w-full h-full drop-shadow-[0_8px_12px_rgba(0,0,0,0.7)]"
          shapeRendering="crispEdges"
        >
          <defs>
            {/* Shield Gradient */}
            <linearGradient id="shieldGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#0284c7" />
              <stop offset="60%" stopColor="#0369a1" />
              <stop offset="100%" stopColor="#0c4a6e" />
            </linearGradient>
            {/* Sword Blade Gradient */}
            <linearGradient id="swordBlade" x1="0" y1="0" x2="1" y2="0">
              <stop offset="0%" stopColor="#f8fafc" />
              <stop offset="50%" stopColor="#e2e8f0" />
              <stop offset="100%" stopColor="#94a3b8" />
            </linearGradient>
            {/* Armor Gradient */}
            <linearGradient id="plateArmor" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#64748b" />
              <stop offset="50%" stopColor="#475569" />
              <stop offset="100%" stopColor="#334155" />
            </linearGradient>
          </defs>

          {/* ================= HERO CAPE (Behind body) ================= */}
          <path
            d={
              action === 'attack'
                ? "M 28 48 L 8 68 L 12 88 L 22 92 L 34 58 Z"
                : "M 28 48 L 14 74 L 16 94 L 28 92 L 32 58 Z"
            }
            fill="#1e3a8a"
            stroke="#0f172a"
            strokeWidth="1.5"
          />
          {/* Cape highlight fold */}
          <path
            d={action === 'attack' ? "M 26 50 L 14 76" : "M 26 50 L 18 78"}
            stroke="#3b82f6"
            strokeWidth="1.5"
          />

          {/* ================= LEGS & GREAVES ================= */}
          {/* Left Leg (Back) */}
          <rect x="30" y="74" width="8" height="18" fill="#334155" stroke="#0f172a" strokeWidth="1.5" />
          <rect x="28" y="90" width="12" height="6" fill="#1e293b" stroke="#0f172a" strokeWidth="1.5" />
          {/* Left Boot highlight */}
          <rect x="30" y="90" width="4" height="2" fill="#64748b" />

          {/* Right Leg (Front - Stride) */}
          <rect
            x={action === 'attack' ? "48" : "42"}
            y="74"
            width="9"
            height="18"
            fill="url(#plateArmor)"
            stroke="#0f172a"
            strokeWidth="1.5"
          />
          <rect
            x={action === 'attack' ? "46" : "40"}
            y="90"
            width="13"
            height="6"
            fill="#1e293b"
            stroke="#0f172a"
            strokeWidth="1.5"
          />
          <rect x={action === 'attack' ? "48" : "42"} y="90" width="5" height="2" fill="#94a3b8" />

          {/* ================= TORSO & CHESTPLATE ================= */}
          {/* Belt & Faulds */}
          <rect x="32" y="68" width="22" height="7" fill="#78350f" stroke="#0f172a" strokeWidth="1.5" />
          <rect x="41" y="69" width="4" height="5" fill="#facc15" stroke="#78350f" strokeWidth="1" />

          {/* Steel Breastplate */}
          <rect x="32" y="46" width="22" height="22" fill="url(#plateArmor)" stroke="#0f172a" strokeWidth="1.5" />
          {/* Royal Blue Surcoat / Tabbard Accent */}
          <rect x="39" y="47" width="8" height="20" fill="#0284c7" />
          <rect x="42" y="49" width="2" height="16" fill="#facc15" />

          {/* ================= HELMET & VISOR ================= */}
          {/* Helmet Dome */}
          <rect x="34" y="24" width="18" height="18" fill="url(#plateArmor)" stroke="#0f172a" strokeWidth="1.5" />
          {/* Helmet Cheek Guard */}
          <rect x="34" y="38" width="6" height="7" fill="#334155" stroke="#0f172a" strokeWidth="1" />
          {/* Visor Slit with glowing heroic eye */}
          <rect x="40" y="32" width="12" height="3.5" fill="#09090b" />
          <rect x="44" y="32.5" width="4" height="2.5" fill="#38bdf8" />
          {/* Helmet Crest Plume (Cyan / White) */}
          <path
            d="M 32 24 C 28 14 36 10 44 8 C 48 12 46 20 44 24 Z"
            fill="#38bdf8"
            stroke="#0369a1"
            strokeWidth="1.5"
          />
          <path d="M 38 12 C 40 10 43 14 43 18" stroke="#f0f9ff" strokeWidth="1.5" fill="none" />

          {/* ================= LEFT ARM & SWORD ================= */}
          {/* Sword orientation changes based on action */}
          {action === 'attack' ? (
            /* Attack: Sword thrusts forward horizontally */
            <g id="player-sword-thrust">
              {/* Arm thrusting forward */}
              <rect x="48" y="52" width="14" height="6" fill="#475569" stroke="#0f172a" strokeWidth="1.5" />
              {/* Hand/Gauntlet */}
              <rect x="62" y="51" width="5" height="8" fill="#64748b" stroke="#0f172a" strokeWidth="1" />
              {/* Sword Hilt & Crossguard */}
              <rect x="67" y="44" width="4" height="20" fill="#facc15" stroke="#78350f" strokeWidth="1" />
              <rect x="65" y="53" width="3" height="4" fill="#78350f" />
              {/* Sword Blade Horizontal */}
              <polygon points="71,52 92,54 94,55 92,56 71,58" fill="url(#swordBlade)" stroke="#334155" strokeWidth="1" />
              {/* Blade Center Fuller Line */}
              <line x1="72" y1="55" x2="91" y2="55" stroke="#cbd5e1" strokeWidth="1" />
            </g>
          ) : action === 'block' ? (
            /* Block: Sword lowered behind shield */
            <g id="player-sword-rest">
              <rect x="30" y="52" width="6" height="12" fill="#475569" stroke="#0f172a" strokeWidth="1.5" />
              <rect x="32" y="60" width="3" height="22" fill="url(#swordBlade)" stroke="#334155" strokeWidth="1" />
              <rect x="30" y="58" width="8" height="3" fill="#facc15" stroke="#78350f" strokeWidth="1" />
            </g>
          ) : (
            /* Idle: Sword held ready at an angle */
            <g id="player-sword-idle">
              {/* Pauldron / Shoulder guard */}
              <rect x="48" y="44" width="8" height="8" fill="#64748b" stroke="#0f172a" strokeWidth="1.5" />
              <rect x="50" y="44" width="4" height="3" fill="#94a3b8" />
              {/* Arm holding hilt */}
              <rect x="50" y="52" width="7" height="9" fill="#475569" stroke="#0f172a" strokeWidth="1.5" />
              <rect x="52" y="58" width="5" height="5" fill="#64748b" stroke="#0f172a" strokeWidth="1" />
              {/* Sword Crossguard */}
              <rect x="53" y="54" width="12" height="3" fill="#facc15" stroke="#78350f" strokeWidth="1" />
              <rect x="56" y="57" width="3" height="5" fill="#78350f" />
              {/* Sword Blade Angled Upwards */}
              <polygon points="57,54 74,18 76,14 77,18 61,54" fill="url(#swordBlade)" stroke="#334155" strokeWidth="1" />
              <line x1="59" y1="53" x2="75" y2="17" stroke="#ffffff" strokeWidth="1" />
            </g>
          )}

          {/* ================= RIGHT ARM & KITE SHIELD ================= */}
          {action === 'block' ? (
            /* Block: Shield raised forward large */
            <g id="player-shield-block">
              {/* Forearm pushing forward */}
              <rect x="42" y="48" width="10" height="7" fill="#475569" stroke="#0f172a" strokeWidth="1.5" />
              {/* Large Raised Heater Shield */}
              <path
                d="M 52 32 L 76 32 L 74 62 L 64 78 L 54 62 Z"
                fill="url(#shieldGrad)"
                stroke="#0f172a"
                strokeWidth="2"
              />
              {/* Shield Gold Trim */}
              <path
                d="M 55 35 L 73 35 L 71 60 L 64 73 L 57 60 Z"
                stroke="#facc15"
                strokeWidth="1.5"
                fill="none"
              />
              {/* Dragon Slayer Emblem Star */}
              <polygon points="64,44 66,50 72,50 67,54 69,60 64,56 59,60 61,54 56,50 62,50" fill="#fef08a" stroke="#ca8a04" strokeWidth="0.8" />
            </g>
          ) : (
            /* Normal Shield Position */
            <g id="player-shield-ready">
              {/* Right Pauldron */}
              <rect x="28" y="44" width="7" height="7" fill="#64748b" stroke="#0f172a" strokeWidth="1.5" />
              {/* Forearm */}
              <rect x="26" y="51" width="7" height="8" fill="#475569" stroke="#0f172a" strokeWidth="1.5" />
              {/* Shield on arm facing 3/4 */}
              <path
                d="M 24 40 L 40 40 L 38 66 L 32 78 L 26 66 Z"
                fill="url(#shieldGrad)"
                stroke="#0f172a"
                strokeWidth="2"
              />
              {/* Gold rim */}
              <path
                d="M 26 43 L 38 43 L 36 64 L 32 74 L 28 64 Z"
                stroke="#facc15"
                strokeWidth="1.2"
                fill="none"
              />
              {/* Crest Cross / Rune */}
              <rect x="31" y="47" width="2.5" height="16" fill="#facc15" />
              <rect x="27" y="52" width="10" height="2.5" fill="#facc15" />
            </g>
          )}

          {/* Danger sweat drops if low HP */}
          {isLowHp && (
            <g>
              <rect x="52" y="24" width="2" height="3" fill="#38bdf8" className="animate-pulse" />
              <rect x="54" y="27" width="1.5" height="2" fill="#7dd3fc" />
            </g>
          )}
        </svg>

        {/* ================= VISUAL EFFECTS OVERLAYS ================= */}
        {/* Attack Slash Wave Particle */}
        {action === 'attack' && (
          <div className="absolute top-1/3 -right-8 pointer-events-none z-20">
            <svg viewBox="0 0 64 64" className="w-16 h-16 slash-arc">
              <path
                d="M 8 16 C 36 20 48 36 54 52"
                stroke="#38bdf8"
                strokeWidth="4"
                strokeLinecap="round"
                fill="none"
                filter="drop-shadow(0 0 8px #0284c7)"
              />
              <path
                d="M 12 18 C 34 24 44 38 48 50"
                stroke="#f0f9ff"
                strokeWidth="2"
                strokeLinecap="round"
                fill="none"
              />
              {/* Sparkles */}
              <rect x="42" y="28" width="3" height="3" fill="#facc15" />
              <rect x="52" y="44" width="2" height="2" fill="#38bdf8" />
            </svg>
          </div>
        )}

        {/* Shield Barrier Energy Dome on QTE Block */}
        {action === 'block' && (
          <div className="absolute -inset-4 flex items-center justify-center pointer-events-none z-30">
            <div className="w-40 h-40 rounded-full border-4 border-cyan-300 bg-cyan-400/20 backdrop-blur-[1px] shield-barrier flex items-center justify-center">
              <div className="w-32 h-32 rounded-full border-2 border-white/60" />
            </div>
            {/* Spark deflections */}
            <div className="absolute right-0 top-1/3 w-3 h-3 bg-yellow-300 animate-ping" />
            <div className="absolute right-4 bottom-1/3 w-2 h-2 bg-cyan-200 animate-ping" />
          </div>
        )}
      </div>

      {/* Hero Label Pill */}
      <div className="mt-1 flex items-center gap-1.5 px-2 py-0.5 bg-[#0f0b1e] border border-[#2b2247] z-10">
        <span
          className={`w-2 h-2 inline-block ${
            isLowHp ? 'bg-rose-500 animate-ping' : 'bg-cyan-400'
          }`}
        />
        <span className="font-pixel text-[8px] text-cyan-300 tracking-wider">
          HERO
        </span>
      </div>
    </div>
  );
};
