import React from 'react';

export const DungeonBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none">
      {/* Layer 1: Atmospheric Fantasy Sky - Open twilight indigo to deep azure */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#060a18] via-[#0d1730] to-[#12243d]" />

      {/* Layer 2: Celestial Moon & Stars in Upper Sky */}
      <div className="absolute top-6 right-16 sm:right-28 w-16 h-16 sm:w-20 sm:h-20 pointer-events-none">
        {/* Crescent Moon Pixel Art */}
        <div className="relative w-full h-full">
          <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-amber-100/95 shadow-[0_0_30px_rgba(254,243,199,0.35)]" />
          <div className="absolute top-1 left-2 w-13 h-13 sm:w-15 sm:h-15 rounded-full bg-[#060a18]" />
        </div>
      </div>

      {/* Distant Twinkling Pixel Stars */}
      <div className="absolute top-8 left-12 w-1.5 h-1.5 bg-cyan-100 opacity-80 animate-pulse" />
      <div className="absolute top-16 left-1/4 w-2 h-2 bg-amber-200 opacity-70" />
      <div className="absolute top-6 left-1/2 w-1.5 h-1.5 bg-blue-200 opacity-75 animate-pulse" />
      <div className="absolute top-20 left-2/3 w-2 h-2 bg-purple-200 opacity-70" />
      <div className="absolute top-12 right-1/3 w-1.5 h-1.5 bg-white opacity-85" />
      <div className="absolute top-28 right-10 w-1.5 h-1.5 bg-cyan-200 opacity-70 animate-pulse" />

      {/* Layer 3: High Aerial Fluffy Pixel Clouds around the Dragon's airspace (Right & Center) */}
      <div className="absolute top-8 sm:top-14 right-4 sm:right-16 w-80 sm:w-96 opacity-60 pointer-events-none cloud-float-slow">
        <svg viewBox="0 0 240 60" className="w-full h-auto fill-[#283b5e]/70" shapeRendering="crispEdges">
          {/* Cloud Base Tier */}
          <rect x="20" y="30" width="190" height="18" />
          <rect x="50" y="18" width="130" height="20" />
          <rect x="80" y="8" width="80" height="18" />
          {/* Cloud Highlights */}
          <rect x="84" y="8" width="60" height="4" fill="#64748b" opacity="0.6" />
          <rect x="54" y="18" width="40" height="4" fill="#64748b" opacity="0.5" />
        </svg>
      </div>

      <div className="absolute top-24 sm:top-32 right-1/4 sm:right-1/3 w-64 sm:w-80 opacity-40 pointer-events-none cloud-float-fast">
        <svg viewBox="0 0 200 50" className="w-full h-auto fill-[#1e2d4a]/75" shapeRendering="crispEdges">
          <rect x="15" y="24" width="160" height="16" />
          <rect x="40" y="14" width="110" height="18" />
          <rect x="70" y="6" width="60" height="14" />
        </svg>
      </div>

      {/* Layer 4: Distant Forest & Mountain Horizon */}
      <div className="absolute bottom-28 sm:bottom-36 inset-x-0 h-44 sm:h-56 opacity-55 pointer-events-none">
        <svg viewBox="0 0 1200 240" preserveAspectRatio="none" className="w-full h-full fill-[#0b1c28]">
          {/* Distant mountain peaks */}
          <polygon points="0,240 0,160 90,110 180,170 300,90 440,165 580,80 720,160 860,105 1020,185 1140,120 1200,160 1200,240" />
          {/* Evergreen Tree silhouettes on ridges */}
          <polygon points="140,150 145,120 150,150" fill="#081520" />
          <polygon points="155,155 160,128 165,155" fill="#081520" />
          <polygon points="400,140 406,110 412,140" fill="#081520" />
          <polygon points="420,150 425,122 430,150" fill="#081520" />
          <polygon points="680,140 686,112 692,140" fill="#081520" />
        </svg>
      </div>

      {/* Layer 5: Rolling Green Hills Middle-ground */}
      <div className="absolute bottom-20 sm:bottom-28 inset-x-0 h-28 sm:h-36 pointer-events-none opacity-85">
        <svg viewBox="0 0 1200 140" preserveAspectRatio="none" className="w-full h-full">
          {/* Back lush green ridge */}
          <path
            d="M 0,140 L 0,80 Q 200,30 420,70 T 880,50 T 1200,75 L 1200,140 Z"
            fill="#14462b"
          />
          {/* Front meadow curve */}
          <path
            d="M 0,140 L 0,90 Q 250,55 540,85 T 1050,60 T 1200,90 L 1200,140 Z"
            fill="#195937"
          />
        </svg>
      </div>

      {/* Layer 6: Lush Green Land & Grassy Meadow Battle Terrain Foreground */}
      <div className="absolute bottom-0 inset-x-0 h-24 sm:h-28 bg-[#113a23] border-t-4 border-[#22c55e]">
        {/* Pixel Grass blades border pattern */}
        <div className="absolute -top-3 inset-x-0 h-3 overflow-hidden flex pointer-events-none">
          {Array.from({ length: 120 }).map((_, i) => (
            <div
              key={i}
              className="w-2.5 h-3 bg-[#22c55e] shrink-0"
              style={{
                clipPath:
                  i % 3 === 0
                    ? 'polygon(0% 100%, 50% 0%, 100% 100%)'
                    : i % 3 === 1
                    ? 'polygon(20% 100%, 70% 10%, 100% 100%)'
                    : 'polygon(0% 100%, 30% 0%, 80% 100%)'
              }}
            />
          ))}
        </div>

        {/* Earth / Loam Stratum underneath the grass */}
        <div className="absolute inset-x-0 top-3 h-2 bg-[#15803d]" />
        <div className="absolute inset-x-0 top-5 bottom-0 bg-gradient-to-b from-[#194729] to-[#0c2415]">
          {/* Pixel Soil Texture Dots */}
          <div className="absolute inset-0 opacity-25 bg-[radial-gradient(#4ade80_1px,transparent_1px)] [background-size:10px_10px]" />
        </div>
      </div>

      {/* Ambient Rising Nature Fireflies & Spores */}
      <div className="absolute bottom-24 left-1/6 w-1.5 h-1.5 bg-emerald-300 pixel-ember" style={{ animationDelay: '0.4s', animationDuration: '3.6s' }} />
      <div className="absolute bottom-32 left-1/3 w-1.5 h-1.5 bg-lime-200 pixel-ember" style={{ animationDelay: '1.4s', animationDuration: '3.2s' }} />
      <div className="absolute bottom-28 right-1/4 w-1.5 h-1.5 bg-cyan-200 pixel-ember" style={{ animationDelay: '2.2s', animationDuration: '4.0s' }} />
    </div>
  );
};

