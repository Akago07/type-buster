import React from 'react';
import { Difficulty } from '../types';

interface StatsPanelProps {
  score: number;
  combo: number;
  accuracy: number;
  reactionTime: number;
  difficulty: Difficulty;
  roundsSurvived: number;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({
  score,
  combo,
  accuracy,
  reactionTime,
  difficulty,
  roundsSurvived
}) => {
  return (
    <div
      id="stats-panel"
      className="w-full max-w-xl mx-auto flex items-center justify-between gap-2 px-3 py-1.5 bg-[#0e0a1b] border border-[#261f3d] rounded-sm select-none font-pixel text-[8px] text-gray-400"
    >
      {/* Score */}
      <div className="flex items-center gap-1.5">
        <span>SCORE:</span>
        <span id="score-display" className="text-amber-300 font-bold">
          {score.toLocaleString()}
        </span>
        {combo > 1 && (
          <span className="text-cyan-400 font-bold ml-1">
            {combo}x
          </span>
        )}
      </div>

      {/* Accuracy */}
      <div className="flex items-center gap-1.5">
        <span>ACCURACY:</span>
        <span id="accuracy-display" className="text-cyan-300 font-bold">
          {accuracy}%
        </span>
      </div>

      {/* Reaction */}
      <div className="flex items-center gap-1.5 hidden xs:flex">
        <span>REACTION:</span>
        <span
          id="reaction-time-display"
          className={`font-bold ${
            reactionTime > 0 && reactionTime < 450
              ? 'text-emerald-400'
              : reactionTime <= 750
              ? 'text-amber-400'
              : 'text-rose-400'
          }`}
        >
          {reactionTime > 0 ? `${reactionTime}ms` : '--'}
        </span>
      </div>

      {/* Rank / Wave */}
      <div className="flex items-center gap-1.5">
        <span className="uppercase text-gray-400">W:{roundsSurvived}</span>
        <span
          id="difficulty-badge"
          className={`uppercase font-bold px-1 py-0.5 border ${
            difficulty === 'easy'
              ? 'text-emerald-300 border-emerald-800'
              : difficulty === 'medium'
              ? 'text-amber-300 border-amber-800'
              : 'text-rose-300 border-rose-800'
          }`}
        >
          {difficulty}
        </span>
      </div>
    </div>
  );
};
