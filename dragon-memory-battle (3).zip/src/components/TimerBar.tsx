import React from 'react';

interface TimerBarProps {
  timeLeft: number;
  totalTime: number;
}

export const TimerBar: React.FC<TimerBarProps> = ({ timeLeft, totalTime }) => {
  const percentage = Math.max(0, Math.min(100, (timeLeft / totalTime) * 100));

  const isLowTime = percentage <= 30;
  const isMidTime = percentage > 30 && percentage <= 60;

  return (
    <div
      id="timer-bar"
      className="w-full max-w-xl mx-auto flex flex-col p-1.5 bg-[#120d22] border border-[#2e264b] rounded-sm select-none"
    >
      {/* Label and Seconds */}
      <div className="flex justify-between items-center mb-1 font-pixel text-[8px] sm:text-[9px]">
        <span className="text-gray-400 tracking-wider">TIME</span>
        <span
          className={`font-mono font-bold tracking-wider ${
            isLowTime
              ? 'text-rose-400 animate-pulse'
              : isMidTime
              ? 'text-amber-300'
              : 'text-cyan-300'
          }`}
        >
          {timeLeft.toFixed(2)}s
        </span>
      </div>

      {/* Retro Arcade Countdown Segmented Bar */}
      <div className="relative h-3 sm:h-3.5 w-full bg-[#080612] border border-black overflow-hidden rounded-xs">
        {/* Fill Bar */}
        <div
          id="timer-fill"
          className={`h-full transition-all duration-75 ease-linear ${
            isLowTime
              ? 'bg-gradient-to-r from-red-600 to-rose-500 animate-pulse'
              : isMidTime
              ? 'bg-gradient-to-r from-amber-600 to-yellow-400'
              : 'bg-gradient-to-r from-cyan-600 via-teal-500 to-emerald-400'
          }`}
          style={{ width: `${percentage}%` }}
        />

        {/* Segment dividers */}
        <div className="absolute inset-0 flex pointer-events-none">
          {Array.from({ length: 9 }).map((_, i) => (
            <div
              key={i}
              className="h-full border-r border-black/60 flex-1"
            />
          ))}
          <div className="flex-1" />
        </div>
      </div>
    </div>
  );
};
