import React from 'react';
import { FloatingCombatText } from '../types';

interface DragonBossProps {
  isDamage: boolean;
  isAttack: boolean;
  isSpecialAttack?: boolean;
  floatingTexts: FloatingCombatText[];
  dragonHp: number;
}

export const DragonBoss: React.FC<DragonBossProps> = ({
  isDamage,
  isAttack,
  isSpecialAttack = false,
  floatingTexts,
  dragonHp
}) => {
  const isEnraged = dragonHp <= 30;

  return (
    <div
      id="dragon-container"
      className="relative flex flex-col items-center select-none"
    >
      {/* Floating Cloud Beds beneath the Flying Dragon */}
      <div className="absolute -bottom-4 right-1/2 translate-x-1/2 pointer-events-none z-0 opacity-75">
        <svg viewBox="0 0 160 40" className="w-44 sm:w-56 h-auto fill-[#3b5278]/60 cloud-float-fast" shapeRendering="crispEdges">
          <rect x="20" y="18" width="120" height="14" />
          <rect x="45" y="8" width="80" height="16" />
          <rect x="65" y="0" width="40" height="12" />
          <rect x="48" y="8" width="50" height="3" fill="#93c5fd" opacity="0.4" />
        </svg>
      </div>

      {/* Secondary Distant Cloud */}
      <div className="absolute top-2 -right-8 pointer-events-none z-0 opacity-50">
        <svg viewBox="0 0 100 30" className="w-28 sm:w-36 h-auto fill-[#223554]/70 cloud-float-slow" shapeRendering="crispEdges">
          <rect x="10" y="12" width="80" height="10" />
          <rect x="25" y="4" width="50" height="12" />
        </svg>
      </div>

      {/* Aerial Hovering Dragon Box */}
      <div
        id="dragon-sprite"
        className={`relative z-10 w-48 sm:w-60 md:w-72 h-48 sm:h-60 md:h-72 transition-transform ${
          isDamage
            ? 'damage'
            : isAttack
            ? 'attack'
            : 'dragon-flying'
        }`}
      >
        {/* Dragon Aura Glow Behind Wings */}
        <div
          className={`absolute inset-4 rounded-full blur-2xl transition-all duration-300 pointer-events-none ${
            isSpecialAttack
              ? 'bg-rose-500/50 animate-ping'
              : isDamage
              ? 'bg-rose-600/40'
              : isAttack
              ? 'bg-amber-500/40'
              : isEnraged
              ? 'bg-red-600/30 animate-pulse'
              : 'bg-purple-900/25'
          }`}
        />

        {/* 16-Bit Pixel Art Dragon SVG */}
        <svg
          viewBox="0 0 128 128"
          className="w-full h-full drop-shadow-[0_12px_24px_rgba(0,0,0,0.85)]"
          shapeRendering="crispEdges"
        >
          <defs>
            <linearGradient id="dragonSkin" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#991b1b" />
              <stop offset="60%" stopColor="#581c87" />
              <stop offset="100%" stopColor="#1e112a" />
            </linearGradient>
            <linearGradient id="dragonBelly" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f59e0b" />
              <stop offset="50%" stopColor="#d97706" />
              <stop offset="100%" stopColor="#92400e" />
            </linearGradient>
            <linearGradient id="wingMembrane" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#dc2626" />
              <stop offset="100%" stopColor="#4c0519" />
            </linearGradient>
          </defs>

          {/* ================= LEFT WING (BEATING WING) ================= */}
          <g id="left-wing" className="wing-left-anim">
            <path
              d="M 40 44 L 14 20 L 4 22 L 2 34 L 12 46 L 22 58 L 36 62 Z"
              fill="url(#wingMembrane)"
              stroke="#0f0508"
              strokeWidth="2"
            />
            {/* Wing rib bones */}
            <path
              d="M 14 20 L 26 34 L 22 54 M 4 22 L 16 44"
              stroke="#b91c1c"
              strokeWidth="2"
              fill="none"
            />
            {/* Claws on wing joints */}
            <rect x="12" y="18" width="4" height="4" fill="#facc15" stroke="#78350f" strokeWidth="1" />
            <rect x="2" y="20" width="4" height="4" fill="#ca8a04" stroke="#78350f" strokeWidth="1" />
          </g>

          {/* ================= RIGHT WING (BEATING WING) ================= */}
          <g id="right-wing" className="wing-right-anim">
            <path
              d="M 88 44 L 114 20 L 124 22 L 126 34 L 116 46 L 106 58 L 92 62 Z"
              fill="url(#wingMembrane)"
              stroke="#0f0508"
              strokeWidth="2"
            />
            {/* Wing rib bones */}
            <path
              d="M 114 20 L 102 34 L 106 54 M 124 22 L 112 44"
              stroke="#b91c1c"
              strokeWidth="2"
              fill="none"
            />
            {/* Claws on wing joints */}
            <rect x="112" y="18" width="4" height="4" fill="#facc15" stroke="#78350f" strokeWidth="1" />
            <rect x="122" y="20" width="4" height="4" fill="#ca8a04" stroke="#78350f" strokeWidth="1" />
          </g>

          {/* ================= DRAGON TAIL WITH SPINES ================= */}
          <path
            d="M 64 88 L 76 96 L 90 102 L 102 98 L 108 88 L 114 90 L 112 102 L 98 110 L 80 108 L 64 96 Z"
            fill="#4a0414"
            stroke="#0f0508"
            strokeWidth="2"
          />
          {/* Tail Spines */}
          <polygon points="76,96 82,92 84,98" fill="#f59e0b" stroke="#0f0508" strokeWidth="1" />
          <polygon points="90,102 96,98 98,104" fill="#f59e0b" stroke="#0f0508" strokeWidth="1" />
          {/* Tail Flame Barb Tip */}
          <polygon points="110,86 120,82 122,90 128,86 122,98 114,98" fill="#f59e0b" />
          <polygon points="112,88 120,86 118,92" fill="#ef4444" />

          {/* ================= DRAGON TORSO & SCALES ================= */}
          <ellipse
            cx="64"
            cy="74"
            rx="22"
            ry="25"
            fill="url(#dragonSkin)"
            stroke="#0f0508"
            strokeWidth="2"
          />

          {/* Scaled Underbelly */}
          <path
            d="M 52 62 C 52 56 76 56 76 62 L 74 90 C 74 94 54 94 54 90 Z"
            fill="url(#dragonBelly)"
            stroke="#451a03"
            strokeWidth="1.5"
          />
          {/* Pixelated Belly Plate Ridges */}
          <line x1="54" y1="68" x2="74" y2="68" stroke="#78350f" strokeWidth="2" />
          <line x1="55" y1="76" x2="73" y2="76" stroke="#78350f" strokeWidth="2" />
          <line x1="56" y1="84" x2="72" y2="84" stroke="#78350f" strokeWidth="2" />

          {/* Back Spines */}
          <polygon points="61,54 64,48 67,54" fill="#f59e0b" stroke="#0f0508" strokeWidth="1" />

          {/* ================= DRAGON HEAD & HORNS ================= */}
          {/* Left Horn */}
          <polygon
            points="50,34 36,18 30,12 38,16 46,24 54,32"
            fill="#f1f5f9"
            stroke="#0f172a"
            strokeWidth="1.5"
          />
          <polygon points="36,18 30,12 34,20" fill="#94a3b8" />
          {/* Right Horn */}
          <polygon
            points="78,34 92,18 98,12 90,16 82,24 74,32"
            fill="#f1f5f9"
            stroke="#0f172a"
            strokeWidth="1.5"
          />
          <polygon points="92,18 98,12 94,20" fill="#94a3b8" />

          {/* Head Base */}
          <path
            d="M 46 36 L 82 36 L 88 46 L 82 58 L 64 64 L 46 58 L 40 46 Z"
            fill="url(#dragonSkin)"
            stroke="#0f0508"
            strokeWidth="2"
          />

          {/* Brow Ridge */}
          <path d="M 44 42 L 64 46 L 84 42" stroke="#1f030a" strokeWidth="3" fill="none" />

          {/* Glowing Eyes */}
          <rect
            x="48"
            y="42"
            width="8"
            height="4.5"
            fill={isSpecialAttack || isEnraged ? '#ff0044' : '#fef08a'}
          />
          <rect x="51" y="43" width="3" height="3" fill="#dc2626" />

          <rect
            x="72"
            y="42"
            width="8"
            height="4.5"
            fill={isSpecialAttack || isEnraged ? '#ff0044' : '#fef08a'}
          />
          <rect x="74" y="43" width="3" height="3" fill="#dc2626" />

          {/* Snout & Nostrils */}
          <rect x="60" y="52" width="2" height="2" fill="#000" />
          <rect x="66" y="52" width="2" height="2" fill="#000" />

          {/* Fangs & Jaw */}
          <polygon points="50,58 53,64 56,58" fill="#ffffff" />
          <polygon points="72,58 75,64 78,58" fill="#ffffff" />
          <polygon points="61,58 64,65 67,58" fill="#ffffff" />

          {/* ================= DRAGON CLAWS ================= */}
          {/* Left Forearm & Claws */}
          <ellipse cx="44" cy="88" rx="8" ry="6" fill="#581c87" stroke="#0f0508" strokeWidth="1.5" />
          <rect x="38" y="90" width="3.5" height="5" fill="#f8fafc" stroke="#0f0508" strokeWidth="1" />
          <rect x="43" y="91" width="3.5" height="5" fill="#f8fafc" stroke="#0f0508" strokeWidth="1" />
          <rect x="48" y="90" width="3.5" height="5" fill="#f8fafc" stroke="#0f0508" strokeWidth="1" />

          {/* Right Forearm & Claws */}
          <ellipse cx="84" cy="88" rx="8" ry="6" fill="#581c87" stroke="#0f0508" strokeWidth="1.5" />
          <rect x="78" y="90" width="3.5" height="5" fill="#f8fafc" stroke="#0f0508" strokeWidth="1" />
          <rect x="83" y="91" width="3.5" height="5" fill="#f8fafc" stroke="#0f0508" strokeWidth="1" />
          <rect x="88" y="90" width="3.5" height="5" fill="#f8fafc" stroke="#0f0508" strokeWidth="1" />
        </svg>

        {/* Dragon Attack Fire Breath / Fireball (aimed across toward player on left) */}
        {(isAttack || isSpecialAttack) && (
          <div className="absolute top-1/2 -left-16 sm:-left-28 -translate-y-1/2 z-20 flex items-center pointer-events-none">
            {/* Fiery Blast Ball */}
            <div className="relative flex items-center">
              <div className="w-16 sm:w-24 h-12 sm:h-16 bg-gradient-to-l from-yellow-200 via-orange-500 to-red-600 rounded-l-full blur-[2px] animate-pulse" />
              <div className="absolute left-2 w-8 sm:w-12 h-6 sm:h-8 bg-yellow-100 rounded-full blur-[1px]" />
              {/* Flying Pixel Embers towards player */}
              <div className="absolute -left-6 -top-2 w-3 h-3 bg-yellow-300 pixel-ember" />
              <div className="absolute -left-12 top-4 w-4 h-4 bg-orange-500 pixel-ember" />
              <div className="absolute -left-8 top-8 w-3 h-3 bg-red-500 pixel-ember" />
            </div>
          </div>
        )}
      </div>

      {/* Floating Combat Text Popups ("-20 HP", "+150 PTS", "CRITICAL!", etc.) */}
      <div
        id="combat-text-container"
        className="absolute inset-0 pointer-events-none z-30"
      >
        {floatingTexts.map((item) => (
          <div
            key={item.id}
            className="absolute floating-text-anim font-bold text-xs sm:text-sm tracking-widest uppercase"
            style={{
              left: `${item.x}%`,
              top: `${item.y}%`,
              color:
                item.type === 'damage'
                  ? '#ff3344'
                  : item.type === 'score'
                  ? '#ffd700'
                  : item.type === 'critical'
                  ? '#00f5a0'
                  : item.type === 'heal'
                  ? '#38bdf8'
                  : '#f97316'
            }}
          >
            {item.text}
          </div>
        ))}
      </div>

      {/* Flying Shadow on Ground Platform (Scales with hover) */}
      <div className="mt-2 w-36 sm:w-48 h-5 bg-[#080512] rounded-full border-b border-[#282042] opacity-70 blur-[1px] animate-pulse" />

      {/* Boss Label Pill */}
      <div className="mt-1 flex items-center gap-1.5 px-2 py-0.5 bg-[#0f0b1e] border border-[#2b2247] z-10">
        <span
          className={`w-2 h-2 inline-block ${
            isEnraged ? 'bg-amber-400 animate-ping' : 'bg-rose-600'
          }`}
        />
        <span className="font-pixel text-[8px] text-rose-300 tracking-wider">
          ANCIENT DRAGON
        </span>
      </div>
    </div>
  );
};
