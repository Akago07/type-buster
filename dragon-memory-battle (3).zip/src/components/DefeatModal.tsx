import React from 'react';
import { GameStats, Difficulty } from '../types';
import { soundManager } from '../audio';

interface DefeatModalProps {
  stats: GameStats;
  difficulty: Difficulty;
  onRetry: () => void;
  onChangeSetup?: () => void;
}

export const DefeatModal: React.FC<DefeatModalProps> = ({
  stats,
  difficulty,
  onRetry,
  onChangeSetup
}) => {
  const accuracy =
    stats.totalAttempts > 0
      ? Math.round((stats.correctAnswers / stats.totalAttempts) * 100)
      : 0;

  return (
    <div
      id="defeat-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-[2px] select-none"
    >
      <div className="relative w-full max-w-md bg-[#160a10] border-2 border-rose-600 rounded-sm p-6 flex flex-col items-center shadow-[0_0_30px_rgba(225,29,72,0.3)]">
        {/* Skull Emblem */}
        <div className="w-12 h-12 bg-rose-600/20 border border-rose-600 flex items-center justify-center mb-3">
          <span className="font-pixel text-xl text-rose-400">☠</span>
        </div>

        <h2 className="font-pixel text-lg sm:text-xl text-rose-400 font-black tracking-widest text-center">
          YOU FELL IN BATTLE
        </h2>
        <p className="font-retro text-sm text-gray-300 text-center mb-4">
          The dragon proved too fierce on {difficulty.toUpperCase()} mode
        </p>

        {/* Clean Stats Grid */}
        <div className="w-full bg-[#0a0508] p-3.5 border border-[#3b121c] flex flex-col gap-2 font-pixel text-[9px] mb-5">
          <div className="flex justify-between items-center pb-1.5 border-b border-[#2d0f17]">
            <span className="text-gray-400">SCORE:</span>
            <span className="text-amber-300 font-bold text-sm">
              {stats.score.toLocaleString()}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">WAVES SURVIVED:</span>
            <span className="text-gray-200 font-bold">{stats.roundsSurvived}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">ACCURACY:</span>
            <span className="text-rose-300 font-bold">{accuracy}%</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">WRONG ANSWERS:</span>
            <span className="text-rose-400 font-bold">{stats.wrongAnswers}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">MISSED TIMERS:</span>
            <span className="text-rose-400 font-bold">{stats.missedAnswers}</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2">
          <button
            type="button"
            id="retry-defeat-btn"
            onClick={() => {
              soundManager.playButtonClick();
              onRetry();
            }}
            className="pixel-btn pixel-btn-red py-2.5 px-6 text-xs font-bold w-full tracking-wider"
          >
            TRY AGAIN
          </button>

          {onChangeSetup && (
            <button
              type="button"
              id="change-setup-defeat-btn"
              onClick={() => {
                soundManager.playButtonClick();
                onChangeSetup();
              }}
              className="pixel-btn py-2 px-6 text-[10px] text-gray-300 bg-[#1e1736] border-[#362b5a] w-full"
            >
              CHANGE SETUP
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

