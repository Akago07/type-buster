import React from 'react';
import { Difficulty, InputMode } from '../types';
import { soundManager } from '../audio';

interface SetupModalProps {
  difficulty: Difficulty;
  setDifficulty: (diff: Difficulty) => void;
  inputMode: InputMode;
  setInputMode: (mode: InputMode) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  onStartGame: () => void;
}

export const SetupModal: React.FC<SetupModalProps> = ({
  difficulty,
  setDifficulty,
  inputMode,
  setInputMode,
  soundEnabled,
  setSoundEnabled,
  onStartGame
}) => {
  return (
    <div
      id="setup-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-[2px] select-none"
    >
      <div className="relative w-full max-w-md bg-[#130f24] border-2 border-amber-500/80 rounded-sm p-5 sm:p-6 flex flex-col items-center shadow-[0_0_24px_rgba(245,158,11,0.2)]">
        {/* Title */}
        <h1 className="font-pixel text-base sm:text-lg text-center text-amber-300 font-bold tracking-wider mb-1">
          DRAGON MEMORY BATTLE
        </h1>
        <p className="font-retro text-sm text-gray-300 mb-5 text-center">
          Cognitive Letter Memory RPG Boss Battle
        </p>

        {/* Setup Content */}
        <div className="w-full flex flex-col gap-4">
          {/* Section 1: Input Control */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center font-pixel text-[9px]">
              <span className="text-cyan-300">INPUT CONTROL</span>
              <span className="text-gray-400">
                {inputMode === 'keyboard' ? 'KEYBOARD' : 'CLICK/TOUCH'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                id="mode-keyboard-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setInputMode('keyboard');
                }}
                className={`pixel-btn py-2.5 px-2 text-xs font-bold ${
                  inputMode === 'keyboard'
                    ? 'pixel-btn-cyan active border-cyan-400'
                    : 'bg-[#1b1532] text-gray-300 border-[#2f254e]'
                }`}
              >
                KEYBOARD
              </button>

              <button
                type="button"
                id="mode-click-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setInputMode('click');
                }}
                className={`pixel-btn py-2.5 px-2 text-xs font-bold ${
                  inputMode === 'click'
                    ? 'pixel-btn-cyan active border-cyan-400'
                    : 'bg-[#1b1532] text-gray-300 border-[#2f254e]'
                }`}
              >
                CLICK / TOUCH
              </button>
            </div>
          </div>

          {/* Section 2: Difficulty */}
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between items-center font-pixel text-[9px]">
              <span className="text-amber-300">DIFFICULTY</span>
              <span className="text-gray-400">
                {difficulty === 'easy'
                  ? '4.0s / 4 RUNES'
                  : difficulty === 'medium'
                  ? '2.8s / 6 RUNES'
                  : '1.8s / 8 RUNES'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                id="diff-easy-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setDifficulty('easy');
                }}
                className={`pixel-btn py-2 text-[10px] font-bold ${
                  difficulty === 'easy'
                    ? 'pixel-btn-green active border-emerald-400'
                    : 'bg-[#1b1532] text-emerald-400 border-[#2f254e]'
                }`}
              >
                EASY
              </button>

              <button
                type="button"
                id="diff-medium-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setDifficulty('medium');
                }}
                className={`pixel-btn py-2 text-[10px] font-bold ${
                  difficulty === 'medium'
                    ? 'pixel-btn-gold active border-amber-400'
                    : 'bg-[#1b1532] text-amber-400 border-[#2f254e]'
                }`}
              >
                MEDIUM
              </button>

              <button
                type="button"
                id="diff-hard-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setDifficulty('hard');
                }}
                className={`pixel-btn py-2 text-[10px] font-bold ${
                  difficulty === 'hard'
                    ? 'pixel-btn-red active border-rose-400'
                    : 'bg-[#1b1532] text-rose-400 border-[#2f254e]'
                }`}
              >
                HARD
              </button>
            </div>
          </div>

          {/* Section 3: Audio Toggle */}
          <div className="flex items-center justify-between border-t border-[#251e3e] pt-3">
            <span className="font-pixel text-[9px] text-gray-300">
              SOUND FX:
            </span>
            <button
              type="button"
              id="sound-toggle-btn"
              onClick={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                soundManager.enabled = next;
                if (next) soundManager.playButtonClick();
              }}
              className={`pixel-btn px-3 py-1 text-[9px] ${
                soundEnabled ? 'pixel-btn-gold' : 'bg-gray-800 text-gray-400'
              }`}
            >
              {soundEnabled ? 'FX: ON' : 'FX: OFF'}
            </button>
          </div>

          {/* Clean Mission Briefing */}
          <div className="bg-[#0b0816] p-2.5 border border-[#231a3d] text-gray-300 text-xs font-retro">
            Memorize the rune target in the HUD and strike matching letters quickly. Slay the flying dragon and survive Quick Time Events at 50% and 20% boss HP!
          </div>
        </div>

        {/* Start Game Action Button */}
        <button
          type="button"
          id="start-battle-btn"
          onClick={() => {
            soundManager.playButtonClick();
            onStartGame();
          }}
          className="pixel-btn pixel-btn-gold mt-5 py-3 px-8 text-sm font-bold w-full tracking-widest"
        >
          START BATTLE
        </button>
      </div>
    </div>
  );
};
