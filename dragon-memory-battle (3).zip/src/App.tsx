/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Difficulty,
  InputMode,
  GameState,
  DifficultyConfig,
  FloatingCombatText,
  GameStats,
  PlayerAction,
  QTEConfig
} from './types';
import { soundManager } from './audio';
import { DungeonBackground } from './components/DungeonBackground';
import { HealthBar } from './components/HealthBar';
import { DragonBoss } from './components/DragonBoss';
import { PlayerCharacter } from './components/PlayerCharacter';
import { TargetLetterDisplay } from './components/TargetLetterDisplay';
import { AnswerButtons } from './components/AnswerButtons';
import { KeyboardPanel } from './components/KeyboardPanel';
import { TimerBar } from './components/TimerBar';
import { StatsPanel } from './components/StatsPanel';
import { SetupModal } from './components/SetupModal';
import { VictoryModal } from './components/VictoryModal';
import { DefeatModal } from './components/DefeatModal';
import { QuickTimeEvent } from './components/QuickTimeEvent';

const DIFFICULTY_CONFIGS: Record<Difficulty, DifficultyConfig> = {
  easy: {
    name: 'easy',
    label: 'Easy',
    roundTimeSeconds: 4.0,
    optionCount: 4,
    playerDamageOnMiss: 10,
    playerDamageOnWrong: 10,
    dragonDamageOnHit: 15,
    scorePerHit: 100,
    badgeColor: 'text-emerald-400 border-emerald-500'
  },
  medium: {
    name: 'medium',
    label: 'Medium',
    roundTimeSeconds: 2.8,
    optionCount: 6,
    playerDamageOnMiss: 15,
    playerDamageOnWrong: 15,
    dragonDamageOnHit: 20,
    scorePerHit: 150,
    badgeColor: 'text-amber-400 border-amber-500'
  },
  hard: {
    name: 'hard',
    label: 'Hard',
    roundTimeSeconds: 1.8,
    optionCount: 8,
    playerDamageOnMiss: 20,
    playerDamageOnWrong: 20,
    dragonDamageOnHit: 25,
    scorePerHit: 200,
    badgeColor: 'text-rose-400 border-rose-500'
  }
};

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

export default function App() {
  // Game Configuration State
  const [gameState, setGameState] = useState<GameState>('setup');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [inputMode, setInputMode] = useState<InputMode>('keyboard');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Health and Battle Entities
  const [playerHp, setPlayerHp] = useState<number>(100);
  const [dragonHp, setDragonHp] = useState<number>(100);
  const [maxPlayerHp] = useState<number>(100);
  const [maxDragonHp] = useState<number>(100);

  // Character Action Animation State
  const [playerAction, setPlayerAction] = useState<PlayerAction>('idle');

  // QTE State
  const [qteTriggered50, setQteTriggered50] = useState<boolean>(false);
  const [qteTriggered20, setQteTriggered20] = useState<boolean>(false);
  const [activeQTE, setActiveQTE] = useState<QTEConfig | null>(null);

  // Round Logic State
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [targetLetter, setTargetLetter] = useState<string>('A');
  const [options, setOptions] = useState<string[]>([]);
  const [roundStartTime, setRoundStartTime] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(2.8);
  const [isAnsweringLocked, setIsAnsweringLocked] = useState<boolean>(false);

  // Feedback and Animations State
  const [feedbackState, setFeedbackState] = useState<{ [key: string]: 'correct' | 'wrong' | null }>({});
  const [isDragonDamage, setIsDragonDamage] = useState<boolean>(false);
  const [isDragonAttack, setIsDragonAttack] = useState<boolean>(false);
  const [isScreenShake, setIsScreenShake] = useState<boolean>(false);
  const [floatingTexts, setFloatingTexts] = useState<FloatingCombatText[]>([]);
  const [lastKey, setLastKey] = useState<string | null>(null);
  const [isKeyPressed, setIsKeyPressed] = useState<boolean>(false);

  // Comprehensive Game Statistics
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    combo: 0,
    maxCombo: 0,
    correctAnswers: 0,
    wrongAnswers: 0,
    missedAnswers: 0,
    totalAttempts: 0,
    reactionTimes: [],
    averageReactionTime: 0,
    bestReactionTime: Infinity,
    roundsSurvived: 0
  });

  // Add floating combat text popup
  const addCombatText = useCallback(
    (text: string, type: FloatingCombatText['type'], x = 50, y = 45) => {
      const id = `${Date.now()}-${Math.random()}`;
      setFloatingTexts((prev) => [...prev, { id, text, type, x, y }]);
      setTimeout(() => {
        setFloatingTexts((prev) => prev.filter((item) => item.id !== id));
      }, 900);
    },
    []
  );

  // Generate a new round with target letter and distractors
  const generateNewRound = useCallback((currentDiff: Difficulty) => {
    const config = DIFFICULTY_CONFIGS[currentDiff];
    const randomIndex = Math.floor(Math.random() * ALPHABET.length);
    const target = ALPHABET[randomIndex];

    // Pick (optionCount - 1) unique distractors
    const pool = ALPHABET.filter((c) => c !== target);
    const shuffledPool = [...pool].sort(() => 0.5 - Math.random());
    const distractors = shuffledPool.slice(0, config.optionCount - 1);

    // Combine and shuffle options
    const roundOptions = [...distractors, target].sort(() => 0.5 - Math.random());

    setTargetLetter(target);
    setOptions(roundOptions);
    setTimeLeft(config.roundTimeSeconds);
    setFeedbackState({});
    setIsAnsweringLocked(false);
    setRoundStartTime(performance.now());
  }, []);

  // Handle Start / Restart Game
  const handleStartGame = useCallback(() => {
    setPlayerHp(maxPlayerHp);
    setDragonHp(maxDragonHp);
    setRoundNumber(1);
    setIsDragonDamage(false);
    setIsDragonAttack(false);
    setIsScreenShake(false);
    setFloatingTexts([]);
    setLastKey(null);
    setPlayerAction('idle');
    setQteTriggered50(false);
    setQteTriggered20(false);
    setActiveQTE(null);

    setStats({
      score: 0,
      combo: 0,
      maxCombo: 0,
      correctAnswers: 0,
      wrongAnswers: 0,
      missedAnswers: 0,
      totalAttempts: 0,
      reactionTimes: [],
      averageReactionTime: 0,
      bestReactionTime: Infinity,
      roundsSurvived: 0
    });

    setGameState('playing');
    generateNewRound(difficulty);
  }, [maxPlayerHp, maxDragonHp, difficulty, generateNewRound]);

  // Handle QTE Success (Player held all required keys together)
  const handleQTESuccess = useCallback(() => {
    if (!activeQTE) return;

    // Player blocks attack with shield
    setPlayerAction('block');
    setTimeout(() => setPlayerAction('idle'), 700);

    const bonus = activeQTE.scoreOnSuccess;
    setStats((prev) => ({
      ...prev,
      score: prev.score + bonus
    }));

    addCombatText('DEFLECTED!', 'critical', 25, 40);
    addCombatText(`+${bonus} PTS`, 'score', 25, 55);

    setActiveQTE(null);
    // Resume with fresh round
    setTimeout(() => {
      setRoundNumber((r) => r + 1);
      generateNewRound(difficulty);
    }, 400);
  }, [activeQTE, difficulty, addCombatText, generateNewRound]);

  // Handle QTE Fail (Player ran out of time without holding all keys)
  const handleQTEFail = useCallback(() => {
    if (!activeQTE) return;

    const damage = activeQTE.damageOnFail;
    setIsDragonAttack(true);
    setIsScreenShake(true);
    setPlayerAction('hurt');

    setTimeout(() => setIsDragonAttack(false), 550);
    setTimeout(() => setIsScreenShake(false), 400);
    setTimeout(() => setPlayerAction('idle'), 500);

    const nextHp = Math.max(0, playerHp - damage);
    setPlayerHp(nextHp);

    addCombatText(`-${damage} HP`, 'damage', 25, 45);
    addCombatText('DRAGON STRUCK!', 'miss', 25, 60);

    setActiveQTE(null);

    if (nextHp <= 0) {
      setTimeout(() => {
        soundManager.playDefeatSound();
        setGameState('defeat');
      }, 550);
    } else {
      setTimeout(() => {
        setRoundNumber((r) => r + 1);
        generateNewRound(difficulty);
      }, 450);
    }
  }, [activeQTE, playerHp, difficulty, addCombatText, generateNewRound]);

  // Handle Player Option Selection (Click or Keyboard)
  const handleSelectOption = useCallback(
    (letter: string) => {
      if (gameState !== 'playing' || isAnsweringLocked || activeQTE !== null) return;

      setIsAnsweringLocked(true);
      const reactionTime = Math.round(performance.now() - roundStartTime);
      const isCorrect = letter === targetLetter;
      const config = DIFFICULTY_CONFIGS[difficulty];

      if (isCorrect) {
        // Positive Feedback & Sound
        soundManager.playCorrectSound();
        soundManager.playDragonDamage();
        setFeedbackState({ [letter]: 'correct' });

        // Player attacks and Dragon takes damage
        setPlayerAction('attack');
        setTimeout(() => setPlayerAction('idle'), 500);

        setIsDragonDamage(true);
        setTimeout(() => setIsDragonDamage(false), 450);

        // Score Calculation (Base + Speed Bonus + Combo Multiplier)
        const currentCombo = stats.combo + 1;
        const speedBonus = Math.max(
          0,
          Math.round((config.roundTimeSeconds * 1000 - reactionTime) / 10)
        );
        const roundScore = config.scorePerHit * Math.min(5, currentCombo) + speedBonus;

        // Update Dragon HP
        const nextDragonHp = Math.max(0, dragonHp - config.dragonDamageOnHit);
        setDragonHp(nextDragonHp);

        // Combat text popups
        addCombatText(`-${config.dragonDamageOnHit} HP`, 'damage', 68, 40);
        addCombatText(`+${roundScore} PTS`, 'score', 65, 55);
        if (currentCombo > 2) {
          addCombatText(`${currentCombo}x COMBO!`, 'critical', 50, 25);
        }

        // Update Statistics
        setStats((prev) => {
          const nextReactionTimes = [...prev.reactionTimes, reactionTime];
          const avg = Math.round(
            nextReactionTimes.reduce((a, b) => a + b, 0) / nextReactionTimes.length
          );
          const best = Math.min(prev.bestReactionTime, reactionTime);
          const total = prev.totalAttempts + 1;
          const correct = prev.correctAnswers + 1;

          return {
            ...prev,
            score: prev.score + roundScore,
            combo: currentCombo,
            maxCombo: Math.max(prev.maxCombo, currentCombo),
            correctAnswers: correct,
            totalAttempts: total,
            reactionTimes: nextReactionTimes,
            averageReactionTime: avg,
            bestReactionTime: best,
            roundsSurvived: prev.roundsSurvived + 1
          };
        });

        // Check Victory Condition
        if (nextDragonHp <= 0) {
          setTimeout(() => {
            soundManager.playVictoryFanfare();
            setGameState('victory');
          }, 500);
          return;
        }

        // Check QTE Phase 1: Dragon HP <= 50% (triggers once)
        if (!qteTriggered50 && nextDragonHp <= 50) {
          setQteTriggered50(true);
          setTimeout(() => {
            setActiveQTE({
              phase: '50',
              title: 'DRAGON SPECIAL ATTACK!',
              subtitle: 'HOLD ALL 3 KEYS SIMULTANEOUSLY TO DEFLECT!',
              keys: ['A', 'S', 'D'],
              durationSeconds: 3.5,
              damageOnFail: 25,
              scoreOnSuccess: 500
            });
          }, 400);
          return;
        }

        // Check QTE Phase 2: Dragon HP <= 20% (triggers once)
        if (!qteTriggered20 && nextDragonHp <= 20) {
          setQteTriggered20(true);
          setTimeout(() => {
            setActiveQTE({
              phase: '20',
              title: 'FINAL INFERNAL ATTACK!',
              subtitle: 'HOLD ALL 4 KEYS SIMULTANEOUSLY TO DEFLECT!',
              keys: ['Q', 'W', 'E', 'R'],
              durationSeconds: 3.0,
              damageOnFail: 35,
              scoreOnSuccess: 1000
            });
          }, 400);
          return;
        }

        // Normal transition to next round
        setTimeout(() => {
          setRoundNumber((r) => r + 1);
          generateNewRound(difficulty);
        }, 350);
      } else {
        // Wrong Answer Feedback & Sound
        soundManager.playWrongSound();
        soundManager.playDragonAttack();
        setFeedbackState({ [letter]: 'wrong' });

        // Dragon Attacks & Player Hurt
        setIsDragonAttack(true);
        setIsScreenShake(true);
        setPlayerAction('hurt');

        setTimeout(() => setIsDragonAttack(false), 550);
        setTimeout(() => setIsScreenShake(false), 400);
        setTimeout(() => setPlayerAction('idle'), 500);

        // Player Takes Damage
        const nextPlayerHp = Math.max(0, playerHp - config.playerDamageOnWrong);
        setPlayerHp(nextPlayerHp);

        addCombatText(`-${config.playerDamageOnWrong} HP`, 'damage', 30, 48);
        addCombatText('WRONG RUNE!', 'miss', 30, 62);

        // Update Statistics
        setStats((prev) => ({
          ...prev,
          combo: 0,
          wrongAnswers: prev.wrongAnswers + 1,
          totalAttempts: prev.totalAttempts + 1
        }));

        // Check Defeat Condition
        if (nextPlayerHp <= 0) {
          setTimeout(() => {
            soundManager.playDefeatSound();
            setGameState('defeat');
          }, 550);
          return;
        }

        // Advance to next round
        setTimeout(() => {
          setRoundNumber((r) => r + 1);
          generateNewRound(difficulty);
        }, 400);
      }
    },
    [
      gameState,
      isAnsweringLocked,
      activeQTE,
      roundStartTime,
      targetLetter,
      difficulty,
      dragonHp,
      playerHp,
      stats.combo,
      qteTriggered50,
      qteTriggered20,
      addCombatText,
      generateNewRound
    ]
  );

  // Round Countdown Timer Loop (Paused during QTE)
  useEffect(() => {
    if (gameState !== 'playing' || isAnsweringLocked || activeQTE !== null) return;

    const interval = setInterval(() => {
      setTimeLeft((prevTime) => {
        const nextTime = prevTime - 0.05;

        // Warning tick if time <= 1.0s
        if (nextTime <= 1.0 && nextTime > 0 && Math.round(nextTime * 10) % 3 === 0) {
          soundManager.playWarningTick();
        }

        // Time ran out: Missed round
        if (nextTime <= 0) {
          clearInterval(interval);
          setIsAnsweringLocked(true);

          // Dragon attacks on timeout & Player Hurt
          soundManager.playWrongSound();
          soundManager.playDragonAttack();
          setIsDragonAttack(true);
          setIsScreenShake(true);
          setPlayerAction('hurt');

          setTimeout(() => setIsDragonAttack(false), 550);
          setTimeout(() => setIsScreenShake(false), 400);
          setTimeout(() => setPlayerAction('idle'), 500);

          const config = DIFFICULTY_CONFIGS[difficulty];
          const nextPlayerHp = Math.max(0, playerHp - config.playerDamageOnMiss);
          setPlayerHp(nextPlayerHp);

          addCombatText(`TIME OUT! -${config.playerDamageOnMiss} HP`, 'damage', 30, 48);

          setStats((prev) => ({
            ...prev,
            combo: 0,
            missedAnswers: prev.missedAnswers + 1,
            totalAttempts: prev.totalAttempts + 1
          }));

          if (nextPlayerHp <= 0) {
            setTimeout(() => {
              soundManager.playDefeatSound();
              setGameState('defeat');
            }, 550);
          } else {
            setTimeout(() => {
              setRoundNumber((r) => r + 1);
              generateNewRound(difficulty);
            }, 450);
          }
          return 0;
        }

        return nextTime;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [
    gameState,
    isAnsweringLocked,
    activeQTE,
    difficulty,
    playerHp,
    addCombatText,
    generateNewRound
  ]);

  // Normal Keyboard Event Listener (Ignored during QTE to prevent conflict)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'playing' || activeQTE !== null) return;

      const key = e.key.toUpperCase();
      if (/^[A-Z]$/.test(key)) {
        setLastKey(key);
        setIsKeyPressed(true);
        setTimeout(() => setIsKeyPressed(false), 120);

        if (options.includes(key)) {
          handleSelectOption(key);
        } else {
          // Off-target key press also registers as wrong attempt
          handleSelectOption(key);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, activeQTE, options, handleSelectOption]);

  // Calculate Accuracy Percentage
  const accuracyPercentage =
    stats.totalAttempts > 0
      ? Math.round((stats.correctAnswers / stats.totalAttempts) * 100)
      : 100;

  const currentConfig = DIFFICULTY_CONFIGS[difficulty];

  return (
    <div
      id="dragon-memory-battle"
      className={`relative min-h-screen w-full bg-[#0a0714] text-gray-100 flex flex-col justify-between p-2 sm:p-4 overflow-x-hidden ${
        isScreenShake ? 'screen-shake' : ''
      }`}
    >
      {/* Immersive Parallax Pixel Art Fantasy Background */}
      <DungeonBackground />

      {/* Main Game Interface Structured in 3 Clean Distinct Areas */}
      <div className="relative z-10 w-full max-w-5xl mx-auto flex flex-col gap-3 sm:gap-4 my-auto">
        
        {/* ========================================================
            PART 1: TOP HUD
            Clean, modern-pixelated, non-cluttered
            Left: Player HP | Center: Minimal game info | Right: Dragon HP
           ======================================================== */}
        <header
          id="top-hud"
          className="w-full bg-[#120e24]/90 border border-[#2d244c] rounded-xs p-2.5 sm:p-3 flex flex-col gap-2.5 shadow-[0_4px_16px_rgba(0,0,0,0.6)] backdrop-blur-[1px] select-none"
        >
          {/* Header Row: Title & Compact Controls */}
          <div className="flex justify-between items-center pb-2 border-b border-[#241c3d]">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 bg-amber-400 inline-block" />
              <h1 className="font-pixel text-[11px] sm:text-xs text-amber-300 font-bold tracking-wider">
                DRAGON MEMORY BATTLE
              </h1>
            </div>

            <div className="flex items-center gap-2">
              {/* Sound Toggle */}
              <button
                type="button"
                id="header-sound-btn"
                onClick={() => {
                  const next = !soundEnabled;
                  setSoundEnabled(next);
                  soundManager.enabled = next;
                  if (next) soundManager.playButtonClick();
                }}
                className="pixel-btn px-2 py-1 text-[8px] bg-[#1e1736] text-amber-300 border-[#382c5f]"
                title="Toggle Sound"
              >
                {soundEnabled ? 'SFX: ON' : 'SFX: OFF'}
              </button>

              {/* Setup Menu Button */}
              <button
                type="button"
                id="header-menu-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setGameState('setup');
                }}
                className="pixel-btn px-2 py-1 text-[8px] bg-[#1e1736] text-cyan-300 border-[#382c5f]"
              >
                SETUP
              </button>
            </div>
          </div>

          {/* Health Bars & Center Info Row */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-2 sm:gap-3 items-center">
            {/* Left Column: Player HP */}
            <div className="md:col-span-5">
              <HealthBar
                type="player"
                currentHp={playerHp}
                maxHp={maxPlayerHp}
                label="HERO"
              />
            </div>

            {/* Center Column: Minimal Stats Indicator */}
            <div className="md:col-span-2 flex flex-row md:flex-col justify-between items-center px-2 py-1 bg-[#090613] border border-[#211838] rounded-xs font-pixel text-[8px]">
              <div className="text-gray-400">
                SCORE:{' '}
                <span id="header-score" className="text-amber-300 font-bold">
                  {stats.score}
                </span>
              </div>
              <div className="text-gray-400">
                COMBO:{' '}
                <span className="text-cyan-300 font-bold">
                  {stats.combo}x
                </span>
              </div>
            </div>

            {/* Right Column: Dragon Boss HP */}
            <div className="md:col-span-5">
              <HealthBar
                type="dragon"
                currentHp={dragonHp}
                maxHp={maxDragonHp}
                label="ANCIENT DRAGON"
              />
            </div>
          </div>
        </header>

        {/* ========================================================
            PART 2: MAIN BATTLE ARENA
            Large pixel-art battle arena:
            Sky & floating clouds for the airborne Dragon (Right),
            Lush green land & grassy meadow for the Hero (Left).
           ======================================================== */}
        <main
          id="battle-arena"
          className="relative w-full min-h-[280px] sm:min-h-[320px] md:min-h-[360px] bg-gradient-to-b from-[#09152a]/95 via-[#0d1c36]/90 to-[#0e272b]/95 border border-[#22445e] rounded-xs p-4 sm:p-6 flex items-end justify-between overflow-hidden shadow-[inset_0_0_40px_rgba(0,0,0,0.85)]"
        >
          {/* Arena Sky Clouds Backdrop on Dragon's Upper Airspace */}
          <div className="absolute top-4 right-6 sm:right-16 pointer-events-none opacity-50 cloud-float-slow">
            <svg viewBox="0 0 160 40" className="w-48 sm:w-64 h-auto fill-[#3b557d]" shapeRendering="crispEdges">
              <rect x="20" y="16" width="120" height="14" />
              <rect x="45" y="6" width="70" height="16" />
              <rect x="65" y="0" width="30" height="10" />
            </svg>
          </div>

          <div className="absolute top-16 right-36 sm:right-48 pointer-events-none opacity-30 cloud-float-fast">
            <svg viewBox="0 0 120 32" className="w-36 sm:w-44 h-auto fill-[#243754]" shapeRendering="crispEdges">
              <rect x="15" y="12" width="90" height="12" />
              <rect x="35" y="4" width="50" height="14" />
            </svg>
          </div>

          {/* Arena Ground Landscape: Lush Green Land & Grassy Meadow for the Hero */}
          <div className="absolute bottom-0 inset-x-0 h-16 sm:h-20 pointer-events-none z-0">
            {/* Green Meadow Cliff / Land underneath player on Left */}
            <svg viewBox="0 0 800 80" preserveAspectRatio="none" className="w-full h-full">
              {/* Deep Soil Base Layer */}
              <path d="M 0,80 L 0,25 Q 220,15 420,38 T 800,48 L 800,80 Z" fill="#0c2317" />
              {/* Vibrant green turf grass stratum */}
              <path d="M 0,80 L 0,20 Q 200,10 380,30 Q 560,50 800,42 L 800,80 Z" fill="#15803d" />
              <path d="M 0,80 L 0,16 Q 180,8 350,26 Q 520,44 800,38 L 800,80 Z" fill="#22c55e" />
            </svg>
            {/* Pixel Grass blades border on the player's ground */}
            <div className="absolute top-2 left-0 w-3/5 h-2 overflow-hidden flex pointer-events-none">
              {Array.from({ length: 45 }).map((_, i) => (
                <div
                  key={i}
                  className="w-2 h-2 bg-[#86efac] shrink-0"
                  style={{
                    clipPath: 'polygon(0% 100%, 50% 0%, 100% 100%)'
                  }}
                />
              ))}
            </div>
          </div>

          {/* Player Character Section (Standing firmly on the Left Green Land) */}
          <div className="relative z-10 flex flex-col items-center justify-end h-full pb-2">
            <PlayerCharacter
              action={playerAction}
              hp={playerHp}
              maxHp={maxPlayerHp}
            />
          </div>

          {/* Central Combat Arena Space (Lots of visual breathing room) */}
          <div className="relative flex-1 flex flex-col items-center justify-center pointer-events-none px-2 pb-16 select-none">
            {/* Round / Wave marker subtly in background */}
            <div className="font-pixel text-[9px] text-emerald-400/50 tracking-widest uppercase">
              SKYRIDGE ENCOUNTER
            </div>
          </div>

          {/* Dragon Boss Section (Hovering in Air & Clouds on Right) */}
          <div className="relative z-10 flex flex-col items-center justify-center h-full pb-10 sm:pb-12">
            <DragonBoss
              isDamage={isDragonDamage}
              isAttack={isDragonAttack}
              isSpecialAttack={activeQTE !== null}
              floatingTexts={floatingTexts}
              dragonHp={dragonHp}
            />
          </div>
        </main>

        {/* ========================================================
            PART 3: GAMEPLAY / MEMORY CONTROLS
            Clean, focused memory rune display and crisp answer buttons
           ======================================================== */}
        <section
          id="gameplay-controls"
          className="w-full flex flex-col gap-2.5 sm:gap-3"
        >
          {/* Target Letter Command Display */}
          <TargetLetterDisplay
            targetLetter={targetLetter}
            roundNumber={roundNumber}
          />

          {/* Countdown Round Timer */}
          <TimerBar
            timeLeft={timeLeft}
            totalTime={currentConfig.roundTimeSeconds}
          />

          {/* Keyboard input helper status (if in keyboard mode) */}
          {inputMode === 'keyboard' && (
            <KeyboardPanel
              targetLetter={targetLetter}
              lastKey={lastKey}
              isKeyPressed={isKeyPressed}
            />
          )}

          {/* Clean Answer Buttons Grid */}
          <AnswerButtons
            options={options}
            onSelectOption={handleSelectOption}
            disabled={isAnsweringLocked || gameState !== 'playing' || activeQTE !== null}
            selectedLetter={lastKey}
            feedbackState={feedbackState}
          />

          {/* Secondary Compact Stats Footer Bar */}
          <StatsPanel
            score={stats.score}
            combo={stats.combo}
            accuracy={accuracyPercentage}
            reactionTime={stats.reactionTimes[stats.reactionTimes.length - 1] || 0}
            difficulty={difficulty}
            roundsSurvived={stats.roundsSurvived}
          />
        </section>
      </div>

      {/* ========================================================
          QUICK TIME EVENT (QTE) OVERLAY
          Triggers at 50% HP (3 keys) & 20% HP (4 keys)
         ======================================================== */}
      {activeQTE && (
        <QuickTimeEvent
          config={activeQTE}
          onSuccess={handleQTESuccess}
          onFail={handleQTEFail}
        />
      )}

      {/* Setup / Options Modal */}
      {gameState === 'setup' && (
        <SetupModal
          difficulty={difficulty}
          setDifficulty={setDifficulty}
          inputMode={inputMode}
          setInputMode={setInputMode}
          soundEnabled={soundEnabled}
          setSoundEnabled={setSoundEnabled}
          onStartGame={handleStartGame}
        />
      )}

      {/* Victory Modal */}
      {gameState === 'victory' && (
        <VictoryModal
          stats={stats}
          difficulty={difficulty}
          onPlayAgain={handleStartGame}
          onChangeSetup={() => setGameState('setup')}
        />
      )}

      {/* Defeat Modal */}
      {gameState === 'defeat' && (
        <DefeatModal
          stats={stats}
          difficulty={difficulty}
          onRetry={handleStartGame}
          onChangeSetup={() => setGameState('setup')}
        />
      )}
    </div>
  );
}
