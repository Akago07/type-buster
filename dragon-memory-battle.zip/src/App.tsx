/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Difficulty, InputMode, GameState, DifficultyConfig, FloatingCombatText, GameStats } from './types';
import { soundManager } from './audio';
import { DungeonBackground } from './components/DungeonBackground';
import { HealthBar } from './components/HealthBar';
import { DragonBoss } from './components/DragonBoss';
import { TargetLetterDisplay } from './components/TargetLetterDisplay';
import { AnswerButtons } from './components/AnswerButtons';
import { KeyboardPanel } from './components/KeyboardPanel';
import { TimerBar } from './components/TimerBar';
import { StatsPanel } from './components/StatsPanel';
import { SetupModal } from './components/SetupModal';
import { VictoryModal } from './components/VictoryModal';
import { DefeatModal } from './components/DefeatModal';

const DIFFICULTY_CONFIGS: Record<Difficulty, DifficultyConfig> = {
  easy: {
    name: 'easy',
    label: 'Easy',
    roundTimeSeconds: 4.0,
    optionCount: 4,
    playerDamageOnMiss: 10,
    playerDamageOnWrong: 10,
    dragonDamageOnHit: 15,
    scorePerHit: 100,
    badgeColor: 'text-emerald-400 border-emerald-500'
  },
  medium: {
    name: 'medium',
    label: 'Medium',
    roundTimeSeconds: 2.8,
    optionCount: 6,
    playerDamageOnMiss: 15,
    playerDamageOnWrong: 15,
    dragonDamageOnHit: 20,
    scorePerHit: 150,
    badgeColor: 'text-amber-400 border-amber-500'
  },
  hard: {
    name: 'hard',
    label: 'Hard',
    roundTimeSeconds: 1.8,
    optionCount: 8,
    playerDamageOnMiss: 20,
    playerDamageOnWrong: 20,
    dragonDamageOnHit: 25,
    scorePerHit: 200,
    badgeColor: 'text-rose-400 border-rose-500'
  }
};

const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

export default function App() {
  // Game Configuration State
  const [gameState, setGameState] = useState<GameState>('setup');
  const [difficulty, setDifficulty] = useState<Difficulty>('medium');
  const [inputMode, setInputMode] = useState<InputMode>('keyboard');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  // Health and Battle Entities
  const [playerHp, setPlayerHp] = useState<number>(100);
  const [dragonHp, setDragonHp] = useState<number>(100);
  const [maxPlayerHp] = useState<number>(100);
  const [maxDragonHp] = useState<number>(100);

  // Round Logic State
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [targetLetter, setTargetLetter] = useState<string>('A');
  const [options, setOptions] = useState<string[]>([]);
  const [roundStartTime, setRoundStartTime] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(2.8);
  const [isAnsweringLocked, setIsAnsweringLocked] = useState<boolean>(false);

  // Feedback and Animations State
  const [feedbackState, setFeedbackState] = useState<{ [key: string]: 'correct' | 'wrong' | null }>({});
  const [isDragonDamage, setIsDragonDamage] = useState<boolean>(false);
  const [isDragonAttack, setIsDragonAttack] = useState<boolean>(false);
  const [isScreenShake, setIsScreenShake] = useState<boolean>(false);
  const [floatingTexts, setFloatingTexts] = useState<FloatingCombatText[]>([]);
  const [lastKey, setLastKey] = useState<string | null>(null);
  const [isKeyPressed, setIsKeyPressed] = useState<boolean>(false);

  // Comprehensive Game Statistics
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    combo: 0,
    maxCombo: 0,
    correctAnswers: 0,
    wrongAnswers: 0,
    missedAnswers: 0,
    totalAttempts: 0,
    reactionTimes: [],
    averageReactionTime: 0,
    bestReactionTime: Infinity,
    roundsSurvived: 0
  });

  // Timers and Animation Frame Refs
  const timerRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(0);

  // Add floating combat text popup
  const addCombatText = useCallback((text: string, type: FloatingCombatText['type'], x = 50, y = 45) => {
    const id = `${Date.now()}-${Math.random()}`;
    setFloatingTexts((prev) => [...prev, { id, text, type, x, y }]);
    setTimeout(() => {
      setFloatingTexts((prev) => prev.filter((item) => item.id !== id));
    }, 900);
  }, []);

  // Generate a new round with target letter and distractors
  const generateNewRound = useCallback((currentDiff: Difficulty) => {
    const config = DIFFICULTY_CONFIGS[currentDiff];
    const randomIndex = Math.floor(Math.random() * ALPHABET.length);
    const target = ALPHABET[randomIndex];

    // Pick (optionCount - 1) unique distractors
    const pool = ALPHABET.filter((c) => c !== target);
    const shuffledPool = [...pool].sort(() => 0.5 - Math.random());
    const distractors = shuffledPool.slice(0, config.optionCount - 1);

    // Combine and shuffle options
    const roundOptions = [...distractors, target].sort(() => 0.5 - Math.random());

    setTargetLetter(target);
    setOptions(roundOptions);
    setTimeLeft(config.roundTimeSeconds);
    setFeedbackState({});
    setIsAnsweringLocked(false);
    setRoundStartTime(performance.now());
    lastTimeRef.current = performance.now();
  }, []);

  // Handle Start / Restart Game
  const handleStartGame = useCallback(() => {
    setPlayerHp(maxPlayerHp);
    setDragonHp(maxDragonHp);
    setRoundNumber(1);
    setIsDragonDamage(false);
    setIsDragonAttack(false);
    setIsScreenShake(false);
    setFloatingTexts([]);
    setLastKey(null);

    setStats({
      score: 0,
      combo: 0,
      maxCombo: 0,
      correctAnswers: 0,
      wrongAnswers: 0,
      missedAnswers: 0,
      totalAttempts: 0,
      reactionTimes: [],
      averageReactionTime: 0,
      bestReactionTime: Infinity,
      roundsSurvived: 0
    });

    setGameState('playing');
    generateNewRound(difficulty);
  }, [maxPlayerHp, maxDragonHp, difficulty, generateNewRound]);

  // Handle Player Option Selection (Click or Keyboard)
  const handleSelectOption = useCallback((letter: string) => {
    if (gameState !== 'playing' || isAnsweringLocked) return;

    setIsAnsweringLocked(true);
    const reactionTime = Math.round(performance.now() - roundStartTime);
    const isCorrect = letter === targetLetter;
    const config = DIFFICULTY_CONFIGS[difficulty];

    if (isCorrect) {
      // Positive Feedback & Sound
      soundManager.playCorrectSound();
      soundManager.playDragonDamage();
      setFeedbackState({ [letter]: 'correct' });

      // Trigger Dragon Damage & sparks
      setIsDragonDamage(true);
      setTimeout(() => setIsDragonDamage(false), 450);

      // Score Calculation (Base + Speed Bonus + Combo Multiplier)
      const currentCombo = stats.combo + 1;
      const speedBonus = Math.max(0, Math.round((config.roundTimeSeconds * 1000 - reactionTime) / 10));
      const roundScore = config.scorePerHit * Math.min(5, currentCombo) + speedBonus;

      // Update Dragon HP
      const nextDragonHp = Math.max(0, dragonHp - config.dragonDamageOnHit);
      setDragonHp(nextDragonHp);

      // Combat text popups
      addCombatText(`-${config.dragonDamageOnHit} HP`, 'damage', 52, 40);
      addCombatText(`+${roundScore} PTS`, 'score', 48, 55);
      if (currentCombo > 2) {
        addCombatText(`${currentCombo}x COMBO!`, 'critical', 50, 25);
      }

      // Update Statistics
      setStats((prev) => {
        const nextReactionTimes = [...prev.reactionTimes, reactionTime];
        const avg = Math.round(nextReactionTimes.reduce((a, b) => a + b, 0) / nextReactionTimes.length);
        const best = Math.min(prev.bestReactionTime, reactionTime);
        const total = prev.totalAttempts + 1;
        const correct = prev.correctAnswers + 1;

        return {
          ...prev,
          score: prev.score + roundScore,
          combo: currentCombo,
          maxCombo: Math.max(prev.maxCombo, currentCombo),
          correctAnswers: correct,
          totalAttempts: total,
          reactionTimes: nextReactionTimes,
          averageReactionTime: avg,
          bestReactionTime: best,
          roundsSurvived: prev.roundsSurvived + 1
        };
      });

      // Check Victory Condition
      if (nextDragonHp <= 0) {
        setTimeout(() => {
          soundManager.playVictoryFanfare();
          setGameState('victory');
        }, 500);
        return;
      }

      // Transition to next round
      setTimeout(() => {
        setRoundNumber((r) => r + 1);
        generateNewRound(difficulty);
      }, 350);

    } else {
      // Wrong Answer Feedback & Sound
      soundManager.playWrongSound();
      soundManager.playDragonAttack();
      setFeedbackState({ [letter]: 'wrong' });

      // Trigger Dragon Attack & Screen Shake
      setIsDragonAttack(true);
      setIsScreenShake(true);
      setTimeout(() => setIsDragonAttack(false), 550);
      setTimeout(() => setIsScreenShake(false), 400);

      // Player Takes Damage
      const nextPlayerHp = Math.max(0, playerHp - config.playerDamageOnWrong);
      setPlayerHp(nextPlayerHp);

      addCombatText(`-${config.playerDamageOnWrong} HP`, 'damage', 50, 48);
      addCombatText('WRONG RUNE!', 'miss', 50, 62);

      // Update Statistics
      setStats((prev) => ({
        ...prev,
        combo: 0,
        wrongAnswers: prev.wrongAnswers + 1,
        totalAttempts: prev.totalAttempts + 1
      }));

      // Check Defeat Condition
      if (nextPlayerHp <= 0) {
        setTimeout(() => {
          soundManager.playDefeatSound();
          setGameState('defeat');
        }, 550);
        return;
      }

      // Advance to next round
      setTimeout(() => {
        setRoundNumber((r) => r + 1);
        generateNewRound(difficulty);
      }, 400);
    }
  }, [
    gameState,
    isAnsweringLocked,
    roundStartTime,
    targetLetter,
    difficulty,
    dragonHp,
    playerHp,
    stats.combo,
    addCombatText,
    generateNewRound
  ]);

  // Round Countdown Timer Loop
  useEffect(() => {
    if (gameState !== 'playing' || isAnsweringLocked) return;

    const interval = setInterval(() => {
      setTimeLeft((prevTime) => {
        const nextTime = prevTime - 0.05;

        // Warning tick if time <= 1.0s
        if (nextTime <= 1.0 && nextTime > 0 && Math.round(nextTime * 10) % 3 === 0) {
          soundManager.playWarningTick();
        }

        // Time ran out: Missed round
        if (nextTime <= 0) {
          clearInterval(interval);
          setIsAnsweringLocked(true);

          // Dragon attacks on time out
          soundManager.playWrongSound();
          soundManager.playDragonAttack();
          setIsDragonAttack(true);
          setIsScreenShake(true);
          setTimeout(() => setIsDragonAttack(false), 550);
          setTimeout(() => setIsScreenShake(false), 400);

          const config = DIFFICULTY_CONFIGS[difficulty];
          const nextPlayerHp = Math.max(0, playerHp - config.playerDamageOnMiss);
          setPlayerHp(nextPlayerHp);

          addCombatText(`TIME OUT! -${config.playerDamageOnMiss} HP`, 'damage', 50, 48);

          setStats((prev) => ({
            ...prev,
            combo: 0,
            missedAnswers: prev.missedAnswers + 1,
            totalAttempts: prev.totalAttempts + 1
          }));

          if (nextPlayerHp <= 0) {
            setTimeout(() => {
              soundManager.playDefeatSound();
              setGameState('defeat');
            }, 550);
          } else {
            setTimeout(() => {
              setRoundNumber((r) => r + 1);
              generateNewRound(difficulty);
            }, 450);
          }
          return 0;
        }

        return nextTime;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [gameState, isAnsweringLocked, difficulty, playerHp, addCombatText, generateNewRound]);

  // Keyboard Event Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (gameState !== 'playing') return;

      const key = e.key.toUpperCase();
      if (/^[A-Z]$/.test(key)) {
        setLastKey(key);
        setIsKeyPressed(true);
        setTimeout(() => setIsKeyPressed(false), 120);

        // If the key is one of the available options or if in keyboard mode
        if (options.includes(key)) {
          handleSelectOption(key);
        } else {
          // Off-target key press still registers as wrong attempt
          handleSelectOption(key);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, options, handleSelectOption]);

  // Calculate Accuracy Percentage
  const accuracyPercentage =
    stats.totalAttempts > 0
      ? Math.round((stats.correctAnswers / stats.totalAttempts) * 100)
      : 100;

  const currentConfig = DIFFICULTY_CONFIGS[difficulty];

  return (
    <div
      id="dragon-memory-battle"
      className={`relative min-h-screen w-full bg-[#0b0813] text-gray-100 flex flex-col items-center justify-between p-2 sm:p-4 overflow-x-hidden ${
        isScreenShake ? 'screen-shake' : ''
      }`}
    >
      {/* Immersive Pixel Art Dungeon Background */}
      <DungeonBackground />

      {/* Main Game Arena Container */}
      <div className="relative z-10 w-full max-w-4xl mx-auto flex flex-col items-center gap-3 sm:gap-4 my-auto">
        {/* Top Bar: Controls, Audio & Battle Banner */}
        <header className="w-full flex justify-between items-center bg-[#130f24] border-4 border-[#332b4f] pixel-box px-3 py-2 select-none">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 bg-amber-400 inline-block" />
            <h1 className="font-pixel text-xs sm:text-sm text-amber-300 font-bold tracking-wider hidden xs:inline">
              DRAGON MEMORY BATTLE
            </h1>
          </div>

          <div className="flex items-center gap-2">
            {/* Audio Toggle Button */}
            <button
              type="button"
              id="header-sound-btn"
              onClick={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                soundManager.enabled = next;
                if (next) soundManager.playButtonClick();
              }}
              className="pixel-btn px-2.5 py-1 text-[9px] bg-[#221a3a] text-amber-300"
              title="Toggle Audio"
            >
              {soundEnabled ? 'FX: ON' : 'FX: OFF'}
            </button>

            {/* Setup / Settings Menu Button */}
            <button
              type="button"
              id="header-menu-btn"
              onClick={() => {
                soundManager.playButtonClick();
                setGameState('setup');
              }}
              className="pixel-btn px-2.5 py-1 text-[9px] bg-[#221a3a] text-cyan-300"
            >
              SETUP
            </button>
          </div>
        </header>

        {/* Top Area: Player HP and Dragon HP Bars */}
        <section
          id="health-bars-section"
          className="w-full grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4"
        >
          {/* Player HP */}
          <HealthBar
            type="player"
            currentHp={playerHp}
            maxHp={maxPlayerHp}
            label="PLAYER HERO"
          />

          {/* Dragon Boss HP */}
          <HealthBar
            type="dragon"
            currentHp={dragonHp}
            maxHp={maxDragonHp}
            label="BOSS: DRAGON"
          />
        </section>

        {/* Dragon Area: Boss Sprite & Arena */}
        <section className="w-full">
          <DragonBoss
            isDamage={isDragonDamage}
            isAttack={isDragonAttack}
            floatingTexts={floatingTexts}
            dragonHp={dragonHp}
          />
        </section>

        {/* Question Area: Target Letter Command Display */}
        <section className="w-full">
          <TargetLetterDisplay
            targetLetter={targetLetter}
            roundNumber={roundNumber}
          />
        </section>

        {/* Timer Bar */}
        <section className="w-full">
          <TimerBar
            timeLeft={timeLeft}
            totalTime={currentConfig.roundTimeSeconds}
          />
        </section>

        {/* Input Mode Controls: Keyboard Panel OR Answer Buttons */}
        <section className="w-full flex flex-col gap-3">
          {inputMode === 'keyboard' && (
            <KeyboardPanel
              targetLetter={targetLetter}
              lastKey={lastKey}
              isKeyPressed={isKeyPressed}
            />
          )}

          {/* Answer Buttons (Active in Click Mode AND available as tactile buttons in Keyboard Mode) */}
          <AnswerButtons
            options={options}
            onSelectOption={handleSelectOption}
            disabled={isAnsweringLocked || gameState !== 'playing'}
            selectedLetter={lastKey}
            feedbackState={feedbackState}
          />
        </section>

        {/* Stats Panel / HUD */}
        <section className="w-full">
          <StatsPanel
            score={stats.score}
            combo={stats.combo}
            accuracy={accuracyPercentage}
            reactionTime={stats.reactionTimes[stats.reactionTimes.length - 1] || 0}
            difficulty={difficulty}
            roundsSurvived={stats.roundsSurvived}
          />
        </section>
      </div>

      {/* Retro RPG Setup Modal */}
      {gameState === 'setup' && (
        <SetupModal
          difficulty={difficulty}
          setDifficulty={setDifficulty}
          inputMode={inputMode}
          setInputMode={setInputMode}
          soundEnabled={soundEnabled}
          setSoundEnabled={setSoundEnabled}
          onStartGame={handleStartGame}
        />
      )}

      {/* Epic Pixel Art Victory Modal */}
      {gameState === 'victory' && (
        <VictoryModal
          stats={stats}
          onPlayAgain={handleStartGame}
          onChangeSetup={() => setGameState('setup')}
        />
      )}

      {/* Dramatic Retro Defeat Modal */}
      {gameState === 'defeat' && (
        <DefeatModal
          stats={stats}
          onTryAgain={handleStartGame}
          onChangeSetup={() => setGameState('setup')}
        />
      )}
    </div>
  );
}
