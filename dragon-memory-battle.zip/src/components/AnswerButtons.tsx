import React from 'react';

interface AnswerButtonsProps {
  options: string[];
  onSelectOption: (letter: string) => void;
  disabled?: boolean;
  selectedLetter: string | null;
  feedbackState: { [key: string]: 'correct' | 'wrong' | null };
}

export const AnswerButtons: React.FC<AnswerButtonsProps> = ({
  options,
  onSelectOption,
  disabled = false,
  feedbackState
}) => {
  return (
    <div
      id="answer-buttons"
      className="w-full max-w-xl mx-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 sm:gap-3.5 p-2 select-none"
    >
      {options.map((letter, index) => {
        const feedback = feedbackState[letter];
        const isCorrect = feedback === 'correct';
        const isWrong = feedback === 'wrong';

        return (
          <button
            key={`${letter}-${index}`}
            id={`btn-option-${letter}`}
            type="button"
            disabled={disabled}
            onClick={() => onSelectOption(letter)}
            className={`pixel-btn relative h-16 sm:h-20 w-full flex flex-col items-center justify-center font-pixel text-2xl sm:text-3xl font-bold tracking-wider transition-all focus:outline-none focus:ring-2 focus:ring-amber-400 ${
              isCorrect ? 'correct' : isWrong ? 'wrong' : 'bg-[#261f3d] text-cyan-200'
            }`}
            style={{
              boxShadow:
                isCorrect
                  ? 'inset -4px -4px 0px 0px rgba(0,0,0,0.4), inset 4px 4px 0px 0px rgba(255,255,255,0.4), 0 0 16px #10b981'
                  : isWrong
                  ? 'inset -4px -4px 0px 0px rgba(0,0,0,0.5), inset 4px 4px 0px 0px rgba(255,255,255,0.2), 0 0 16px #ef4444'
                  : 'inset -4px -4px 0px 0px rgba(0,0,0,0.5), inset 4px 4px 0px 0px rgba(255,255,255,0.2), 4px 4px 0px 0px #000'
            }}
          >
            {/* Corner Rune Accent */}
            <span className="absolute top-1.5 left-2 font-mono text-[9px] text-gray-400 opacity-60">
              #{index + 1}
            </span>

            {/* Letter Glyphs */}
            <span className="relative z-10 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
              {letter}
            </span>

            {/* Physical Button Bevel 3D Bottom Edge */}
            <span className="absolute bottom-1 right-2 font-pixel text-[8px] text-gray-500 opacity-50">
              [{letter}]
            </span>
          </button>
        );
      })}
    </div>
  );
};
