import React from 'react';
import { GameStats } from '../types';
import { soundManager } from '../audio';

interface DefeatModalProps {
  stats: GameStats;
  onTryAgain: () => void;
  onChangeSetup: () => void;
}

export const DefeatModal: React.FC<DefeatModalProps> = ({
  stats,
  onTryAgain,
  onChangeSetup
}) => {
  return (
    <div
      id="defeat-screen"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-none select-none"
    >
      <div className="relative w-full max-w-md bg-[#21090f] border-4 border-[#e11d48] pixel-box-red p-6 flex flex-col items-center">
        {/* Cracked / Skull Pixel Motif */}
        <div className="my-2 flex flex-col items-center">
          <div className="w-10 h-8 bg-zinc-400 border-2 border-black flex flex-col items-center justify-center">
            {/* Eye sockets */}
            <div className="flex gap-2">
              <div className="w-2 h-2 bg-black" />
              <div className="w-2 h-2 bg-black" />
            </div>
            {/* Nose socket */}
            <div className="w-1 h-1 bg-black mt-1" />
          </div>
          <div className="w-6 h-3 bg-zinc-300 border-x-2 border-b-2 border-black flex justify-around px-0.5">
            <div className="w-1 h-2 bg-black" />
            <div className="w-1 h-2 bg-black" />
          </div>
        </div>

        {/* Dramatic Defeat Headline */}
        <h2 className="font-pixel text-2xl sm:text-3xl text-red-500 font-black tracking-widest text-center my-3 drop-shadow-[0_4px_0_#000] animate-pulse">
          DEFEAT
        </h2>
        <p className="font-retro text-base text-rose-300 text-center mb-4">
          Your willpower faded before the dragon's scorching breath...
        </p>

        {/* End Game Battle Statistics */}
        <div className="w-full bg-[#0d0407] border-2 border-[#881337] p-4 flex flex-col gap-2 font-pixel text-[10px]">
          <div className="flex justify-between items-center border-b border-[#470818] pb-1.5">
            <span className="text-gray-400">SCORE ATTAINED:</span>
            <span className="text-amber-400 text-xs font-bold">
              {stats.score.toLocaleString()} PTS
            </span>
          </div>

          <div className="flex justify-between items-center border-b border-[#470818] pb-1.5">
            <span className="text-gray-400">FINAL ACCURACY:</span>
            <span className="text-cyan-300 font-bold">
              {stats.totalAttempts > 0
                ? Math.round((stats.correctAnswers / stats.totalAttempts) * 100)
                : 0}
              %
            </span>
          </div>

          <div className="flex justify-between items-center border-b border-[#470818] pb-1.5">
            <span className="text-gray-400">BEST REACTION:</span>
            <span className="text-emerald-300 font-bold">
              {stats.bestReactionTime !== Infinity
                ? `${stats.bestReactionTime}ms`
                : '--'}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">WAVES SURVIVED:</span>
            <span className="text-gray-200 font-bold">
              {stats.roundsSurvived} WAVES
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col sm:flex-row gap-3 mt-6">
          <button
            type="button"
            id="defeat-replay-btn"
            onClick={() => {
              soundManager.playButtonClick();
              onTryAgain();
            }}
            className="pixel-btn pixel-btn-red flex-1 py-3 text-xs font-bold"
          >
            TRY AGAIN
          </button>

          <button
            type="button"
            id="defeat-setup-btn"
            onClick={() => {
              soundManager.playButtonClick();
              onChangeSetup();
            }}
            className="pixel-btn flex-1 py-3 text-xs font-bold bg-[#291f3a] text-gray-200"
          >
            CHANGE SETUP
          </button>
        </div>
      </div>
    </div>
  );
};
