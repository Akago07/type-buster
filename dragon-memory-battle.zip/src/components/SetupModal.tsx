import React from 'react';
import { Difficulty, InputMode } from '../types';
import { soundManager } from '../audio';

interface SetupModalProps {
  difficulty: Difficulty;
  setDifficulty: (diff: Difficulty) => void;
  inputMode: InputMode;
  setInputMode: (mode: InputMode) => void;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean) => void;
  onStartGame: () => void;
}

export const SetupModal: React.FC<SetupModalProps> = ({
  difficulty,
  setDifficulty,
  inputMode,
  setInputMode,
  soundEnabled,
  setSoundEnabled,
  onStartGame
}) => {
  return (
    <div
      id="setup-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-none select-none"
    >
      <div className="relative w-full max-w-lg bg-[#16102a] border-4 border-[#e5a00d] pixel-box-gold p-5 sm:p-7 flex flex-col items-center">
        {/* Decorative Pixel Crown / Crest Header */}
        <div className="flex items-center gap-2 mb-2">
          <span className="w-3 h-3 bg-amber-400 inline-block" />
          <span className="w-4 h-4 bg-amber-300 inline-block" />
          <span className="w-3 h-3 bg-amber-400 inline-block" />
        </div>

        {/* Title */}
        <h1 className="font-pixel text-xl sm:text-2xl text-center text-amber-300 font-bold tracking-wider leading-relaxed drop-shadow-[0_4px_0_#000]">
          DRAGON MEMORY BATTLE
        </h1>
        <p className="font-retro text-base sm:text-lg text-gray-300 mt-1 mb-6 text-center">
          Test your cognitive memory and slay the legendary dungeon beast!
        </p>

        {/* Setup Content Container */}
        <div className="w-full flex flex-col gap-5 bg-[#0e0a1b] p-4 sm:p-5 border-2 border-black">
          {/* Section 1: Input Method Selection */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-pixel text-[9px] sm:text-[10px] text-cyan-300 tracking-wider">
                &gt; SELECT INPUT CONTROL:
              </span>
              <span className="font-pixel text-[8px] text-gray-400">
                {inputMode === 'keyboard' ? '[KEYBOARD PRO]' : '[MOUSE / TOUCH]'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                id="mode-keyboard-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setInputMode('keyboard');
                }}
                className={`pixel-btn py-3 px-2 text-xs sm:text-sm font-bold ${
                  inputMode === 'keyboard'
                    ? 'pixel-btn-cyan active border-cyan-300'
                    : 'bg-[#201838] text-gray-300'
                }`}
              >
                KEYBOARD
              </button>

              <button
                type="button"
                id="mode-click-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setInputMode('click');
                }}
                className={`pixel-btn py-3 px-2 text-xs sm:text-sm font-bold ${
                  inputMode === 'click'
                    ? 'pixel-btn-cyan active border-cyan-300'
                    : 'bg-[#201838] text-gray-300'
                }`}
              >
                CLICK / TOUCH
              </button>
            </div>
          </div>

          {/* Section 2: Difficulty Selection */}
          <div className="flex flex-col gap-2">
            <div className="flex items-center justify-between">
              <span className="font-pixel text-[9px] sm:text-[10px] text-amber-300 tracking-wider">
                &gt; DIFFICULTY LEVEL:
              </span>
              <span className="font-pixel text-[8px] text-gray-400">
                {difficulty === 'easy'
                  ? '4.0s / 4 RUNES'
                  : difficulty === 'medium'
                  ? '2.8s / 6 RUNES'
                  : '1.8s / 8 RUNES'}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2.5">
              <button
                type="button"
                id="diff-easy-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setDifficulty('easy');
                }}
                className={`pixel-btn py-2.5 px-1 text-[10px] sm:text-xs font-bold ${
                  difficulty === 'easy'
                    ? 'pixel-btn-green active border-emerald-300'
                    : 'bg-[#201838] text-emerald-300'
                }`}
              >
                EASY
              </button>

              <button
                type="button"
                id="diff-medium-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setDifficulty('medium');
                }}
                className={`pixel-btn py-2.5 px-1 text-[10px] sm:text-xs font-bold ${
                  difficulty === 'medium'
                    ? 'pixel-btn-gold active border-amber-300'
                    : 'bg-[#201838] text-amber-300'
                }`}
              >
                MEDIUM
              </button>

              <button
                type="button"
                id="diff-hard-btn"
                onClick={() => {
                  soundManager.playButtonClick();
                  setDifficulty('hard');
                }}
                className={`pixel-btn py-2.5 px-1 text-[10px] sm:text-xs font-bold ${
                  difficulty === 'hard'
                    ? 'pixel-btn-red active border-rose-300'
                    : 'bg-[#201838] text-rose-300'
                }`}
              >
                HARD
              </button>
            </div>
          </div>

          {/* Section 3: Retro Audio Sound Toggle */}
          <div className="flex items-center justify-between border-t border-[#231a42] pt-3">
            <span className="font-pixel text-[9px] text-gray-300">
              8-BIT SOUND FX:
            </span>
            <button
              type="button"
              id="sound-toggle-btn"
              onClick={() => {
                const next = !soundEnabled;
                setSoundEnabled(next);
                soundManager.enabled = next;
                if (next) soundManager.playButtonClick();
              }}
              className={`pixel-btn px-3 py-1.5 text-[9px] ${
                soundEnabled ? 'pixel-btn-gold' : 'bg-gray-800 text-gray-400'
              }`}
            >
              {soundEnabled ? 'AUDIO: ON' : 'AUDIO: OFF'}
            </button>
          </div>

          {/* How to Play Rules */}
          <div className="bg-[#07050e] p-2.5 border border-[#231a42] text-gray-300 text-xs font-retro">
            <div className="font-pixel text-[8px] text-amber-400 mb-1">
              BATTLE DIRECTIVE:
            </div>
            When the round starts, memorize the target letter in the HUD and strike the matching rune before the timer drains. Fast accurate hits deal critical damage to the dragon boss!
          </div>
        </div>

        {/* Start Game Action Button */}
        <button
          type="button"
          id="start-battle-btn"
          onClick={() => {
            soundManager.playButtonClick();
            onStartGame();
          }}
          className="pixel-btn pixel-btn-gold mt-6 py-3.5 px-8 text-sm sm:text-base font-bold w-full max-w-xs tracking-widest animate-pulse"
        >
          START BATTLE!
        </button>
      </div>
    </div>
  );
};
