import React from 'react';

export const DungeonBackground: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden select-none">
      {/* Deep castle wall base */}
      <div className="absolute inset-0 bg-[#090710]" />

      {/* Brick texture pattern */}
      <div className="absolute inset-0 dungeon-brick-wall opacity-40" />

      {/* Castle Archway & Pillars Silhouette */}
      <div className="absolute inset-0 flex justify-between pointer-events-none opacity-60">
        {/* Left Stone Pillar */}
        <div className="w-12 sm:w-20 md:w-28 h-full bg-[#110d22] border-r-4 border-[#251e3e] flex flex-col justify-between p-2">
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
        </div>

        {/* Right Stone Pillar */}
        <div className="w-12 sm:w-20 md:w-28 h-full bg-[#110d22] border-l-4 border-[#251e3e] flex flex-col justify-between p-2">
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
          <div className="h-10 border-b-4 border-[#251e3e] bg-[#16112c]" />
        </div>
      </div>

      {/* Upper Dungeon Vault Arch */}
      <div className="absolute top-0 left-0 right-0 h-10 bg-[#16112b] border-b-4 border-[#31274f] flex justify-around items-center px-4">
        <div className="h-2 w-16 bg-[#251d40]" />
        <div className="h-2 w-32 bg-[#251d40]" />
        <div className="h-2 w-16 bg-[#251d40]" />
      </div>

      {/* Wall Torches with Animated Pixel Flames */}
      {/* Left Wall Torch */}
      <div className="absolute top-28 sm:top-36 left-4 sm:left-14 flex flex-col items-center">
        {/* Torch Glow Aura */}
        <div className="absolute -inset-6 bg-amber-500/15 rounded-full blur-xl pointer-events-none" />
        
        {/* Pixel Flame */}
        <div className="torch-flame flex flex-col items-center z-10">
          <div className="w-3 h-3 bg-amber-200" />
          <div className="w-5 h-4 bg-amber-400" />
          <div className="w-7 h-5 bg-orange-600" />
        </div>
        {/* Torch Metal Sconce & Wood */}
        <div className="w-4 h-3 bg-[#3f3b4d] border-2 border-black -mt-1 z-10" />
        <div className="w-2 h-7 bg-[#5c3c1e] border-x-2 border-black z-10" />
        <div className="w-6 h-2 bg-[#272333] border border-black z-10" />
      </div>

      {/* Right Wall Torch */}
      <div className="absolute top-28 sm:top-36 right-4 sm:right-14 flex flex-col items-center">
        {/* Torch Glow Aura */}
        <div className="absolute -inset-6 bg-amber-500/15 rounded-full blur-xl pointer-events-none" />
        
        {/* Pixel Flame */}
        <div className="torch-flame flex flex-col items-center z-10">
          <div className="w-3 h-3 bg-amber-200" />
          <div className="w-5 h-4 bg-amber-400" />
          <div className="w-7 h-5 bg-orange-600" />
        </div>
        {/* Torch Metal Sconce & Wood */}
        <div className="w-4 h-3 bg-[#3f3b4d] border-2 border-black -mt-1 z-10" />
        <div className="w-2 h-7 bg-[#5c3c1e] border-x-2 border-black z-10" />
        <div className="w-6 h-2 bg-[#272333] border border-black z-10" />
      </div>

      {/* Subtle Rising Embers in Background */}
      <div className="absolute bottom-12 left-1/4 w-2 h-2 bg-orange-400 pixel-ember" style={{ animationDelay: '0.2s', animationDuration: '3.2s' }} />
      <div className="absolute bottom-16 left-1/3 w-1.5 h-1.5 bg-amber-300 pixel-ember" style={{ animationDelay: '1.5s', animationDuration: '2.8s' }} />
      <div className="absolute bottom-8 right-1/4 w-2 h-2 bg-red-400 pixel-ember" style={{ animationDelay: '0.8s', animationDuration: '3.6s' }} />
      <div className="absolute bottom-20 right-1/3 w-1.5 h-1.5 bg-yellow-400 pixel-ember" style={{ animationDelay: '2.1s', animationDuration: '2.5s' }} />

      {/* Dungeon Floor Flagstones */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-[#0e0a19] to-transparent border-t-2 border-[#201838]" />

      {/* Subtle Retro CRT Scanline Overlay */}
      <div className="absolute inset-0 retro-scanlines pointer-events-none opacity-40" />
    </div>
  );
};
