import React from 'react';

interface TimerBarProps {
  timeLeft: number;
  totalTime: number;
}

export const TimerBar: React.FC<TimerBarProps> = ({ timeLeft, totalTime }) => {
  const percentage = Math.max(0, Math.min(100, (timeLeft / totalTime) * 100));

  const isLowTime = percentage <= 30;
  const isMidTime = percentage > 30 && percentage <= 60;

  // 12 retro pixel segments
  const segments = 12;

  return (
    <div
      id="timer-bar"
      className="w-full max-w-xl mx-auto flex flex-col p-2.5 bg-[#140f25] border-4 border-[#3c3258] pixel-box select-none"
    >
      {/* Top Label and Milliseconds/Seconds */}
      <div className="flex justify-between items-center mb-1.5 font-pixel text-[9px] sm:text-[10px]">
        <div className="flex items-center gap-1.5">
          <span
            className={`w-2 h-2 inline-block ${
              isLowTime
                ? 'bg-rose-500 animate-ping'
                : isMidTime
                ? 'bg-amber-400'
                : 'bg-cyan-400'
            }`}
          />
          <span className="text-gray-300 tracking-wider">ROUND TIMER</span>
        </div>

        <div className="flex items-center gap-1">
          <span
            className={`font-bold font-mono tracking-wider ${
              isLowTime
                ? 'text-rose-400 animate-pulse'
                : isMidTime
                ? 'text-amber-300'
                : 'text-cyan-300'
            }`}
          >
            {timeLeft.toFixed(2)}s
          </span>
        </div>
      </div>

      {/* Retro Arcade Countdown Segmented Bar */}
      <div className="relative h-5 sm:h-6 w-full bg-[#080611] border-2 border-black p-0.5 overflow-hidden">
        {/* Fill Bar */}
        <div
          id="timer-fill"
          className={`h-full transition-all duration-75 ease-linear ${
            isLowTime
              ? 'bg-gradient-to-r from-red-600 to-rose-500 animate-pulse'
              : isMidTime
              ? 'bg-gradient-to-r from-amber-600 to-yellow-400'
              : 'bg-gradient-to-r from-cyan-600 via-teal-500 to-emerald-400'
          }`}
          style={{ width: `${percentage}%` }}
        >
          {/* Subtle top glare */}
          <div className="h-1 bg-white/30" />
        </div>

        {/* 12 Retro Pixel Block Divider Dividers */}
        <div className="absolute inset-0 flex pointer-events-none">
          {Array.from({ length: segments - 1 }).map((_, i) => (
            <div
              key={i}
              className="h-full border-r-2 border-black/80 flex-1"
            />
          ))}
          <div className="flex-1" />
        </div>
      </div>
    </div>
  );
};
