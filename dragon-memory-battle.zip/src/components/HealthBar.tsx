import React from 'react';

interface HealthBarProps {
  type: 'player' | 'dragon';
  currentHp: number;
  maxHp: number;
  label?: string;
}

export const HealthBar: React.FC<HealthBarProps> = ({
  type,
  currentHp,
  maxHp,
  label
}) => {
  const percentage = Math.max(0, Math.min(100, (currentHp / maxHp) * 100));
  const isPlayer = type === 'player';

  // Warning state (<= 50%), Danger state (<= 30%)
  const isDanger = percentage <= 30;
  const isWarning = percentage > 30 && percentage <= 50;

  const barId = isPlayer ? 'player-hp-bar' : 'dragon-hp-bar';
  const fillId = isPlayer ? 'player-hp-fill' : 'dragon-hp-fill';
  const textId = isPlayer ? 'player-hp-text' : 'dragon-hp-text';

  const defaultLabel = isPlayer ? 'HERO / PLAYER' : 'BOSS: DRAGON';
  const displayLabel = label || defaultLabel;

  // Segment count for 16-bit RPG segmented feel
  const segments = 10;

  return (
    <div
      id={barId}
      className={`relative w-full max-w-sm flex flex-col p-2.5 bg-[#140f24] border-4 ${
        isPlayer ? 'border-[#0891b2]' : 'border-[#be123c]'
      } box-shadow-pixel transition-all ${
        isDanger ? 'danger' : isWarning ? 'warning' : ''
      }`}
      style={{
        boxShadow: `0 -3px 0 0 #000, 0 3px 0 0 #000, -3px 0 0 0 #000, 3px 0 0 0 #000, inset 0 0 0 2px ${
          isPlayer ? '#0e7490' : '#881337'
        }`
      }}
    >
      {/* Header Row: Label and Numeric HP */}
      <div className="flex justify-between items-center mb-1.5 font-pixel text-[10px] sm:text-xs">
        <div className="flex items-center gap-1.5">
          {/* Pixel Icon Badge */}
          <span
            className={`w-2.5 h-2.5 inline-block ${
              isPlayer
                ? isDanger ? 'bg-rose-500 animate-ping' : 'bg-emerald-400'
                : isDanger ? 'bg-amber-400 animate-ping' : 'bg-rose-600'
            }`}
          />
          <span className={`tracking-wider font-bold ${
            isPlayer ? 'text-cyan-300' : 'text-rose-300'
          }`}>
            {displayLabel}
          </span>
        </div>

        <span
          id={textId}
          className={`font-mono font-bold tracking-wider ${
            isDanger ? 'text-red-400 animate-pulse' : isWarning ? 'text-amber-300' : 'text-gray-200'
          }`}
        >
          {Math.round(currentHp)} / {maxHp} HP
        </span>
      </div>

      {/* Retro Bar Outer Frame */}
      <div className="relative h-6 sm:h-7 w-full bg-[#090710] border-2 border-black p-0.5 overflow-hidden">
        {/* Animated Delayed Damage Ghost Bar (shows damage chunk) */}
        <div
          className="absolute inset-y-0.5 left-0.5 bg-amber-500/50 transition-all duration-700 ease-out"
          style={{ width: `calc(${percentage}% - 4px)` }}
        />

        {/* Main HP Fill */}
        <div
          id={fillId}
          className={`relative h-full transition-all duration-300 ease-out ${
            isPlayer
              ? isDanger
                ? 'bg-gradient-to-r from-red-600 via-rose-500 to-red-400'
                : isWarning
                ? 'bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-400'
                : 'bg-gradient-to-r from-emerald-600 via-teal-500 to-cyan-400'
              : isDanger
              ? 'bg-gradient-to-r from-purple-700 via-rose-600 to-amber-500'
              : 'bg-gradient-to-r from-red-700 via-rose-600 to-orange-500'
          }`}
          style={{ width: `${percentage}%` }}
        >
          {/* Top highlight line for 3D retro shine */}
          <div className="absolute top-0 inset-x-0 h-1 bg-white/35" />
          {/* Bottom shadow line */}
          <div className="absolute bottom-0 inset-x-0 h-1 bg-black/40" />
        </div>

        {/* 16-Bit Pixel Grid Segment Dividers Overlay */}
        <div className="absolute inset-0 flex pointer-events-none">
          {Array.from({ length: segments - 1 }).map((_, i) => (
            <div
              key={i}
              className="h-full border-r-2 border-black/70 flex-1"
            />
          ))}
          <div className="flex-1" />
        </div>
      </div>

      {/* Status Warning Pill under bar when in danger */}
      {isDanger && (
        <div className="mt-1 flex justify-end">
          <span className="font-pixel text-[8px] text-red-400 tracking-widest uppercase">
            {isPlayer ? 'CRITICAL DAMAGE!' : 'ENRAGED STATE!'}
          </span>
        </div>
      )}
    </div>
  );
};
