import React from 'react';
import { GameStats } from '../types';
import { soundManager } from '../audio';

interface VictoryModalProps {
  stats: GameStats;
  onPlayAgain: () => void;
  onChangeSetup: () => void;
}

export const VictoryModal: React.FC<VictoryModalProps> = ({
  stats,
  onPlayAgain,
  onChangeSetup
}) => {
  return (
    <div
      id="victory-screen"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-none select-none"
    >
      <div className="relative w-full max-w-md bg-[#1c1507] border-4 border-[#f59e0b] pixel-box-gold p-6 flex flex-col items-center">
        {/* Pixel Stars / Confetti Top Banner */}
        <div className="flex justify-center gap-2 mb-2">
          <span className="w-2.5 h-2.5 bg-yellow-300 animate-spin" />
          <span className="w-3 h-3 bg-amber-400 animate-bounce" />
          <span className="w-2.5 h-2.5 bg-yellow-300 animate-spin" />
        </div>

        {/* CSS Pixel Art Golden Trophy */}
        <div className="my-2 flex flex-col items-center">
          {/* Trophy Cup */}
          <div className="w-14 h-4 bg-amber-300 border-2 border-black" />
          <div className="w-12 h-8 bg-amber-400 border-x-2 border-b-2 border-black flex items-center justify-center">
            <span className="font-pixel text-[10px] text-amber-900 font-black">★</span>
          </div>
          {/* Trophy Stem & Base */}
          <div className="w-4 h-4 bg-amber-500 border-x-2 border-black" />
          <div className="w-16 h-3 bg-amber-600 border-2 border-black" />
        </div>

        {/* Epic Victory Headline */}
        <h2 className="font-pixel text-2xl sm:text-3xl text-yellow-300 font-black tracking-widest text-center my-3 drop-shadow-[0_4px_0_#000] animate-pulse">
          VICTORY!
        </h2>
        <p className="font-retro text-base text-amber-200 text-center mb-4">
          The Ancient Dragon has been vanquished from the dungeons!
        </p>

        {/* End Game Battle Statistics */}
        <div className="w-full bg-[#0d0903] border-2 border-[#854d0e] p-4 flex flex-col gap-2 font-pixel text-[10px]">
          <div className="flex justify-between items-center border-b border-[#3b2505] pb-1.5">
            <span className="text-gray-400">FINAL SCORE:</span>
            <span className="text-amber-300 text-xs font-bold">
              {stats.score.toLocaleString()} PTS
            </span>
          </div>

          <div className="flex justify-between items-center border-b border-[#3b2505] pb-1.5">
            <span className="text-gray-400">ACCURACY:</span>
            <span className="text-cyan-300 font-bold">
              {stats.totalAttempts > 0
                ? Math.round((stats.correctAnswers / stats.totalAttempts) * 100)
                : 100}
              %
            </span>
          </div>

          <div className="flex justify-between items-center border-b border-[#3b2505] pb-1.5">
            <span className="text-gray-400">MAX COMBO:</span>
            <span className="text-emerald-400 font-bold">
              {stats.maxCombo}x HITS
            </span>
          </div>

          <div className="flex justify-between items-center border-b border-[#3b2505] pb-1.5">
            <span className="text-gray-400">BEST REACTION:</span>
            <span className="text-emerald-300 font-bold">
              {stats.bestReactionTime !== Infinity
                ? `${stats.bestReactionTime}ms`
                : '--'}
            </span>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-gray-400">ROUNDS SURVIVED:</span>
            <span className="text-gray-200 font-bold">
              {stats.roundsSurvived} WAVES
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="w-full flex flex-col sm:flex-row gap-3 mt-6">
          <button
            type="button"
            id="victory-replay-btn"
            onClick={() => {
              soundManager.playButtonClick();
              onPlayAgain();
            }}
            className="pixel-btn pixel-btn-gold flex-1 py-3 text-xs font-bold"
          >
            PLAY AGAIN
          </button>

          <button
            type="button"
            id="victory-setup-btn"
            onClick={() => {
              soundManager.playButtonClick();
              onChangeSetup();
            }}
            className="pixel-btn flex-1 py-3 text-xs font-bold bg-[#291f3a] text-gray-200"
          >
            CHANGE SETUP
          </button>
        </div>
      </div>
    </div>
  );
};
