import React from 'react';

interface TargetLetterDisplayProps {
  targetLetter: string;
  roundNumber: number;
}

export const TargetLetterDisplay: React.FC<TargetLetterDisplayProps> = ({
  targetLetter,
  roundNumber
}) => {
  return (
    <div
      id="target-display"
      className="relative w-full max-w-sm mx-auto flex flex-col items-center bg-[#150f29] border-4 border-[#06b6d4] pixel-box p-3 sm:p-4 text-center select-none"
      style={{
        boxShadow:
          '0 -4px 0 0 #000, 0 4px 0 0 #000, -4px 0 0 0 #000, 4px 0 0 0 #000, inset 0 0 0 2px #0891b2, 0 0 16px rgba(6, 182, 212, 0.25)'
      }}
    >
      {/* Retro Command Header Banner */}
      <div className="w-full flex justify-between items-center bg-[#0d091a] px-3 py-1 border-b-2 border-[#241a45] mb-2">
        <div className="flex items-center gap-1.5 font-pixel text-[8px] sm:text-[9px] text-cyan-400">
          <span className="w-2 h-2 bg-cyan-400 inline-block animate-pulse" />
          <span>MISSION TARGET</span>
        </div>
        <div className="font-pixel text-[8px] text-amber-400">
          WAVE {roundNumber}
        </div>
      </div>

      {/* Target Letter Large Frame */}
      <div className="relative w-full py-4 sm:py-5 flex items-center justify-center bg-[#090614] border-2 border-black">
        {/* Subtle grid lines background */}
        <div className="absolute inset-0 opacity-20 bg-[radial-gradient(#06b6d4_1px,transparent_1px)] [background-size:8px_8px]" />

        {/* Center Target Letter */}
        <div
          id="target-letter"
          className="relative z-10 font-pixel text-5xl sm:text-6xl md:text-7xl font-black tracking-widest text-cyan-300 drop-shadow-[0_0_12px_rgba(34,211,238,0.7)] transition-transform duration-75"
        >
          {targetLetter}
        </div>

        {/* Corner Reticle Accents */}
        <div className="absolute top-1 left-1 w-2.5 h-2.5 border-t-2 border-l-2 border-cyan-400" />
        <div className="absolute top-1 right-1 w-2.5 h-2.5 border-t-2 border-r-2 border-cyan-400" />
        <div className="absolute bottom-1 left-1 w-2.5 h-2.5 border-b-2 border-l-2 border-cyan-400" />
        <div className="absolute bottom-1 right-1 w-2.5 h-2.5 border-b-2 border-r-2 border-cyan-400" />
      </div>

      {/* Command prompt subtext */}
      <div className="mt-2 font-pixel text-[8px] sm:text-[9px] text-gray-400 tracking-wider flex items-center gap-1">
        <span className="text-cyan-400">&gt;</span> STRIKE THE MATCHING RUNE
      </div>
    </div>
  );
};
