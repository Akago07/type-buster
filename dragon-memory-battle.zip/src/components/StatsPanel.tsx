import React from 'react';
import { Difficulty } from '../types';

interface StatsPanelProps {
  score: number;
  combo: number;
  accuracy: number;
  reactionTime: number;
  difficulty: Difficulty;
  roundsSurvived: number;
}

export const StatsPanel: React.FC<StatsPanelProps> = ({
  score,
  combo,
  accuracy,
  reactionTime,
  difficulty,
  roundsSurvived
}) => {
  const getDifficultyBadge = (diff: Difficulty) => {
    switch (diff) {
      case 'easy':
        return {
          label: 'EASY',
          bg: 'bg-emerald-950 text-emerald-300 border-emerald-500'
        };
      case 'medium':
        return {
          label: 'MEDIUM',
          bg: 'bg-amber-950 text-amber-300 border-amber-500'
        };
      case 'hard':
        return {
          label: 'HARD',
          bg: 'bg-rose-950 text-rose-300 border-rose-500'
        };
    }
  };

  const badge = getDifficultyBadge(difficulty);

  return (
    <div
      id="stats-panel"
      className="w-full max-w-xl mx-auto grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-2.5 bg-[#120d22] border-4 border-[#3a3059] pixel-box select-none"
    >
      {/* Score Box */}
      <div className="flex flex-col bg-[#0b0816] p-2 border-2 border-black">
        <span className="font-pixel text-[8px] text-gray-400">SCORE</span>
        <div className="flex items-baseline justify-between mt-1">
          <span
            id="score-display"
            className="font-pixel text-xs sm:text-sm text-amber-300 font-bold"
          >
            {score.toLocaleString()}
          </span>
          {combo > 1 && (
            <span className="font-pixel text-[8px] text-cyan-400 animate-bounce">
              {combo}x
            </span>
          )}
        </div>
      </div>

      {/* Accuracy Box */}
      <div className="flex flex-col bg-[#0b0816] p-2 border-2 border-black">
        <span className="font-pixel text-[8px] text-gray-400">ACCURACY</span>
        <span
          id="accuracy-display"
          className="font-pixel text-xs sm:text-sm text-cyan-300 font-bold mt-1"
        >
          {accuracy}%
        </span>
      </div>

      {/* Reaction Time Box */}
      <div className="flex flex-col bg-[#0b0816] p-2 border-2 border-black">
        <span className="font-pixel text-[8px] text-gray-400">REACTION</span>
        <span
          id="reaction-time-display"
          className={`font-pixel text-xs sm:text-sm font-bold mt-1 ${
            reactionTime > 0 && reactionTime < 450
              ? 'text-emerald-400'
              : reactionTime <= 750
              ? 'text-amber-400'
              : 'text-rose-400'
          }`}
        >
          {reactionTime > 0 ? `${reactionTime}ms` : '--'}
        </span>
      </div>

      {/* Difficulty & Wave Box */}
      <div className="flex flex-col bg-[#0b0816] p-2 border-2 border-black justify-between">
        <div className="flex justify-between items-center">
          <span className="font-pixel text-[8px] text-gray-400">RANK</span>
          <span className="font-pixel text-[8px] text-cyan-400">W:{roundsSurvived}</span>
        </div>
        <div
          id="difficulty-badge"
          className={`font-pixel text-[8px] sm:text-[9px] px-1.5 py-0.5 border text-center font-bold uppercase mt-1 ${badge.bg}`}
        >
          {badge.label}
        </div>
      </div>
    </div>
  );
};
