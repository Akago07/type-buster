import React from 'react';
import { FloatingCombatText } from '../types';

interface DragonBossProps {
  isDamage: boolean;
  isAttack: boolean;
  floatingTexts: FloatingCombatText[];
  dragonHp: number;
}

export const DragonBoss: React.FC<DragonBossProps> = ({
  isDamage,
  isAttack,
  floatingTexts,
  dragonHp
}) => {
  const isEnraged = dragonHp <= 30;

  return (
    <div
      id="dragon-container"
      className={`relative w-full max-w-xl mx-auto flex flex-col items-center justify-center p-4 sm:p-6 bg-[#130f21] border-4 border-[#433868] pixel-box transition-all ${
        isDamage ? 'damage' : ''
      } ${isAttack ? 'attack' : ''}`}
    >
      {/* Decorative Dungeon Arena Header & Boss Title */}
      <div className="absolute top-2 inset-x-4 flex justify-between items-center pointer-events-none z-10">
        <div className="flex items-center gap-1.5 bg-[#0a0814] px-2 py-1 border border-[#30284e]">
          <span className="w-2 h-2 bg-red-500 inline-block" />
          <span className="font-pixel text-[9px] text-amber-300 tracking-wider">
            ANCIENT DRAGON
          </span>
        </div>
        <div className="flex items-center gap-1 font-pixel text-[8px] text-gray-400 bg-[#0a0814] px-2 py-1 border border-[#30284e]">
          <span>LEVEL</span>
          <span className="text-red-400 font-bold">99</span>
        </div>
      </div>

      {/* Dragon Arena Subtle Glowing Backlight Aura */}
      <div
        className={`absolute inset-10 rounded-full blur-2xl transition-all duration-300 pointer-events-none ${
          isDamage
            ? 'bg-rose-600/30'
            : isAttack
            ? 'bg-amber-500/40'
            : isEnraged
            ? 'bg-red-600/25 animate-pulse'
            : 'bg-purple-900/30'
        }`}
      />

      {/* Boss Arena Frame & Floor Grate */}
      <div className="relative w-full h-56 sm:h-64 flex items-center justify-center overflow-visible select-none">
        {/* Arena Floor Shadow Pedestal */}
        <div className="absolute bottom-3 w-48 sm:w-64 h-8 bg-[#0a0712] rounded-full border-b-2 border-[#2b2247] opacity-80" />

        {/* Dragon Sprite SVG */}
        <div
          id="dragon-sprite"
          className={`relative z-10 w-44 sm:w-56 md:w-64 h-44 sm:h-56 md:h-64 transition-transform ${
            isDamage ? 'damage' : isAttack ? 'attack' : 'dragon-idle'
          }`}
        >
          <svg
            viewBox="0 0 128 128"
            className="w-full h-full drop-shadow-[0_8px_16px_rgba(0,0,0,0.8)]"
            shapeRendering="crispEdges"
          >
            {/* Defs for gradients & pixel glow */}
            <defs>
              <linearGradient id="dragonSkin" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#800e26" />
                <stop offset="60%" stopColor="#530918" />
                <stop offset="100%" stopColor="#2e050d" />
              </linearGradient>
              <linearGradient id="dragonBelly" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f59e0b" />
                <stop offset="50%" stopColor="#d97706" />
                <stop offset="100%" stopColor="#92400e" />
              </linearGradient>
              <linearGradient id="wingMembrane" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#991b1b" />
                <stop offset="100%" stopColor="#450a0a" />
              </linearGradient>
            </defs>

            {/* Wings Left and Right (Pixelated) */}
            {/* Left Wing Bone & Membrane */}
            <g id="left-wing">
              <path
                d="M 40 44 L 16 24 L 8 26 L 6 36 L 14 46 L 24 56 L 36 60 Z"
                fill="url(#wingMembrane)"
                stroke="#1a0407"
                strokeWidth="2"
              />
              <path
                d="M 16 24 L 28 36 L 24 54 M 8 26 L 18 44"
                stroke="#b91c1c"
                strokeWidth="2"
                fill="none"
              />
              {/* Left Wing Claw Spikes */}
              <rect x="14" y="22" width="4" height="4" fill="#facc15" />
              <rect x="6" y="24" width="4" height="4" fill="#ca8a04" />
            </g>

            {/* Right Wing Bone & Membrane */}
            <g id="right-wing">
              <path
                d="M 88 44 L 112 24 L 120 26 L 122 36 L 114 46 L 104 56 L 92 60 Z"
                fill="url(#wingMembrane)"
                stroke="#1a0407"
                strokeWidth="2"
              />
              <path
                d="M 112 24 L 100 36 L 104 54 M 120 26 L 110 44"
                stroke="#b91c1c"
                strokeWidth="2"
                fill="none"
              />
              {/* Right Wing Claw Spikes */}
              <rect x="110" y="22" width="4" height="4" fill="#facc15" />
              <rect x="118" y="24" width="4" height="4" fill="#ca8a04" />
            </g>

            {/* Tail */}
            <path
              d="M 64 88 L 74 96 L 86 100 L 96 98 L 102 90 L 108 92 L 106 102 L 94 108 L 78 106 L 64 96 Z"
              fill="#530918"
              stroke="#1a0407"
              strokeWidth="2"
            />
            {/* Tail Flame Barb */}
            <polygon points="106,88 114,84 116,92 122,88 116,98 108,98" fill="#f59e0b" />
            <polygon points="108,90 114,88 112,94" fill="#ef4444" />

            {/* Dragon Body Trunk */}
            <ellipse cx="64" cy="74" rx="20" ry="24" fill="url(#dragonSkin)" stroke="#1a0407" strokeWidth="2" />

            {/* Scaled Underbelly */}
            <path
              d="M 54 62 C 54 58 74 58 74 62 L 72 88 C 72 92 56 92 56 88 Z"
              fill="url(#dragonBelly)"
              stroke="#451a03"
              strokeWidth="1.5"
            />
            {/* Belly segments (pixel ridges) */}
            <line x1="56" y1="68" x2="72" y2="68" stroke="#78350f" strokeWidth="2" />
            <line x1="57" y1="76" x2="71" y2="76" stroke="#78350f" strokeWidth="2" />
            <line x1="58" y1="84" x2="70" y2="84" stroke="#78350f" strokeWidth="2" />

            {/* Massive Dragon Head & Horns */}
            {/* Horns */}
            {/* Left Horn */}
            <polygon points="52,36 40,20 34,14 42,18 48,26 56,34" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />
            <polygon points="40,20 34,14 38,22" fill="#94a3b8" />
            {/* Right Horn */}
            <polygon points="76,36 88,20 94,14 86,18 80,26 72,34" fill="#e2e8f0" stroke="#0f172a" strokeWidth="1.5" />
            <polygon points="88,20 94,14 90,22" fill="#94a3b8" />

            {/* Head Base */}
            <path
              d="M 48 38 L 80 38 L 86 48 L 80 60 L 64 64 L 48 60 L 42 48 Z"
              fill="url(#dragonSkin)"
              stroke="#1a0407"
              strokeWidth="2"
            />

            {/* Brow Ridge */}
            <path d="M 46 44 L 64 48 L 82 44" stroke="#2e050d" strokeWidth="3" fill="none" />

            {/* Fiery Glowing Eyes */}
            <rect x="50" y="44" width="7" height="4" fill={isEnraged ? '#ff0000' : '#fef08a'} />
            <rect x="52" y="45" width="3" height="3" fill="#dc2626" />

            <rect x="71" y="44" width="7" height="4" fill={isEnraged ? '#ff0000' : '#fef08a'} />
            <rect x="73" y="45" width="3" height="3" fill="#dc2626" />

            {/* Nostril Steam/Smoke */}
            <rect x="60" y="54" width="2" height="2" fill="#000" />
            <rect x="66" y="54" width="2" height="2" fill="#000" />

            {/* Fangs & Jaw */}
            <polygon points="52,60 55,65 57,60" fill="#f8fafc" />
            <polygon points="71,60 73,65 76,60" fill="#f8fafc" />
            <polygon points="62,60 64,66 66,60" fill="#f8fafc" />

            {/* Front Claws */}
            <g id="dragon-claws">
              {/* Left Claw */}
              <ellipse cx="46" cy="88" rx="7" ry="5" fill="#530918" stroke="#1a0407" strokeWidth="1.5" />
              <rect x="40" y="90" width="3" height="4" fill="#f8fafc" />
              <rect x="45" y="91" width="3" height="4" fill="#f8fafc" />
              <rect x="50" y="90" width="3" height="4" fill="#f8fafc" />

              {/* Right Claw */}
              <ellipse cx="82" cy="88" rx="7" ry="5" fill="#530918" stroke="#1a0407" strokeWidth="1.5" />
              <rect x="76" y="90" width="3" height="4" fill="#f8fafc" />
              <rect x="81" y="91" width="3" height="4" fill="#f8fafc" />
              <rect x="86" y="90" width="3" height="4" fill="#f8fafc" />
            </g>

            {/* Enraged Aura Markings if low HP */}
            {isEnraged && (
              <>
                <circle cx="64" cy="50" r="2" fill="#ff0000" className="animate-ping" />
                <path d="M 44 32 L 48 36 M 84 32 L 80 36" stroke="#ff0044" strokeWidth="2" />
              </>
            )}
          </svg>
        </div>

        {/* Dragon Attack Fire Breath Effect (shown during attack) */}
        {isAttack && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 translate-y-6 z-20 flex flex-col items-center pointer-events-none">
            {/* Fire Blast Beam */}
            <div className="w-24 sm:w-36 h-28 bg-gradient-to-b from-amber-300 via-orange-500 to-red-600 rounded-b-full blur-sm animate-pulse opacity-90" />
            <div className="absolute inset-0 flex justify-center items-center">
              <div className="w-16 h-20 bg-yellow-100 rounded-full blur-[2px]" />
            </div>
            {/* Flying Pixel Fire Particles */}
            <div className="absolute -left-6 top-8 w-3 h-3 bg-yellow-300 pixel-ember" />
            <div className="absolute right-6 top-10 w-4 h-4 bg-orange-500 pixel-ember" />
            <div className="absolute -right-8 top-16 w-3 h-3 bg-red-500 pixel-ember" />
          </div>
        )}

        {/* Floating Combat Text Popups ("-20 HP", "+150 PTS", "CRITICAL!", etc.) */}
        <div id="combat-text-container" className="absolute inset-0 pointer-events-none z-30">
          {floatingTexts.map((item) => (
            <div
              key={item.id}
              className="absolute floating-text-anim font-bold text-xs sm:text-base tracking-widest uppercase"
              style={{
                left: `${item.x}%`,
                top: `${item.y}%`,
                color:
                  item.type === 'damage'
                    ? '#ff3344'
                    : item.type === 'score'
                    ? '#ffd700'
                    : item.type === 'critical'
                    ? '#00f5a0'
                    : item.type === 'heal'
                    ? '#38bdf8'
                    : '#f97316'
              }}
            >
              {item.text}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
