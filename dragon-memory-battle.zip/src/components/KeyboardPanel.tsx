import React from 'react';

interface KeyboardPanelProps {
  targetLetter: string;
  lastKey: string | null;
  isKeyPressed: boolean;
}

export const KeyboardPanel: React.FC<KeyboardPanelProps> = ({
  targetLetter,
  lastKey,
  isKeyPressed
}) => {
  return (
    <div
      id="keyboard-panel"
      className="w-full max-w-xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 p-3 sm:p-4 bg-[#140f25] border-4 border-[#473b6b] pixel-box select-none"
    >
      {/* Instructions */}
      <div className="flex flex-col items-center sm:items-start text-center sm:text-left gap-1">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 bg-emerald-400 inline-block" />
          <span className="font-pixel text-[9px] sm:text-[10px] text-amber-300 tracking-wider">
            KEYBOARD BATTLE LINK ACTIVE
          </span>
        </div>
        <p className="font-retro text-sm text-gray-300">
          Press the matching letter key on your physical keyboard to attack!
        </p>
      </div>

      {/* Retro Mechanical Keycap Display Area */}
      <div className="flex items-center gap-4 bg-[#0c0817] p-2 sm:px-3 border-2 border-black">
        {/* Target Key Info */}
        <div className="flex flex-col items-center">
          <span className="font-pixel text-[8px] text-gray-400 mb-1">TARGET</span>
          <div className="pixel-keycap w-10 h-10 text-cyan-300 text-sm">
            {targetLetter}
          </div>
        </div>

        {/* Divider */}
        <div className="h-8 w-0.5 bg-[#251e3d]" />

        {/* Last Key Pressed with Mechanical Animation */}
        <div className="flex flex-col items-center">
          <span className="font-pixel text-[8px] text-gray-400 mb-1">LAST KEY</span>
          <div
            id="last-key-pressed"
            className={`pixel-keycap w-10 h-10 text-sm ${
              isKeyPressed ? 'pressed bg-[#382b5c] text-amber-300' : 'text-gray-200'
            }`}
          >
            {lastKey ? lastKey.toUpperCase() : '-'}
          </div>
        </div>
      </div>
    </div>
  );
};
