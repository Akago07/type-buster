/**
 * ============================================================================
 * Dragon Memory Battle - Cognitive Gaming Prototype
 * Vanilla JavaScript (No frameworks, no external libraries)
 * ============================================================================
 * 
 * This prototype tests and trains working memory and perceptual reaction time:
 * - Stimulus: Visual alphabet glyph presentation (target)
 * - Task: Immediate cognitive recognition and 4-alternative forced choice (4-AFC)
 * - Difficulty: Adapts timer windows and perceptual distractor similarity
 * ============================================================================
 */

// ============================================================================
// 1. CONFIGURATION & CONSTANTS
// ============================================================================

/**
 * Difficulty configurations defining timer duration and distractor complexity.
 * - Easy: Long reaction window, distinct random distractors
 * - Medium: Moderate window, includes subtly similar letter pairs
 * - Hard: High-speed window, picks high-confusion visual mirror/glyph clusters
 */
const DIFFICULTY_CONFIG = {
  Easy: {
    name: 'Easy',
    timerDurationMs: 3500, // 3.5 seconds
    damageToDragon: 20,
    damageToPlayer: 15,
    scoreBase: 100,
    speedBonusMax: 50
  },
  Medium: {
    name: 'Medium',
    timerDurationMs: 2300, // 2.3 seconds
    damageToDragon: 20,
    damageToPlayer: 15,
    scoreBase: 150,
    speedBonusMax: 100
  },
  Hard: {
    name: 'Hard',
    timerDurationMs: 1400, // 1.4 seconds
    damageToDragon: 20,
    damageToPlayer: 20,
    scoreBase: 220,
    speedBonusMax: 150
  }
};

/**
 * Visually confusing letter clusters used for Medium and Hard difficulty modes.
 * These challenge perceptual differentiation under strict time limits.
 */
const CONFUSING_LETTER_CLUSTERS = [
  ['B', 'D', 'P', 'R', 'Q'],
  ['M', 'W', 'N', 'V', 'U'],
  ['O', 'Q', 'C', 'G', 'D'],
  ['E', 'F', 'T', 'L', 'I'],
  ['I', 'J', 'L', 'T', '1'],
  ['K', 'X', 'Y', 'V'],
  ['S', 'Z', '5', 'E'],
  ['U', 'V', 'W', 'Y']
];

const ALL_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');

// ============================================================================
// 2. GAME STATE
// ============================================================================

let gameState = {
  // Combat Health
  playerHp: 100,
  dragonHp: 100,
  maxHp: 100,

  // Performance Metrics
  score: 0,
  correctAnswers: 0,
  wrongAnswers: 0,
  missedAnswers: 0,
  totalRounds: 0,
  currentStreak: 0,
  consecutiveErrors: 0,

  // Reaction Time Tracking (in milliseconds)
  reactionTimes: [],
  lastReactionTime: 0,
  fastestReactionTime: Infinity,

  // Round Flow State
  currentDifficulty: 'Easy',
  highestDifficultyReached: 'Easy',
  inputMethod: 'Click', // 'Click' | 'Keyboard'
  currentTargetLetter: '',
  currentOptions: [],
  roundStartTime: 0,
  isRoundActive: false,
  isGameOver: false,

  // Settings
  isSoundMuted: false
};

// Timer handles
let roundTimerTimeout = null;
let roundTimerInterval = null;

// ============================================================================
// 3. SOUND SYNTHESIZER (Pure Web Audio API)
// ============================================================================

class SoundManager {
  constructor() {
    this.audioCtx = null;
  }

  /**
   * Lazily initialize AudioContext on user gesture
   */
  initContext() {
    if (!this.audioCtx && typeof (window.AudioContext || window.webkitAudioContext) !== 'undefined') {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
  }

  /**
   * Play simple synthesized sound effects
   * @param {string} type - 'hit' | 'playerDamage' | 'correct' | 'wrong' | 'timeout' | 'win' | 'lose'
   */
  play(type) {
    if (gameState.isSoundMuted) return;
    try {
      this.initContext();
      if (!this.audioCtx) return;

      const now = this.audioCtx.currentTime;

      if (type === 'correct') {
        // Upward chime
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(523.25, now); // C5
        osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.15); // G5
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.2);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.22);
      } else if (type === 'hit') {
        // Dragon hurt sound: punchy low slash
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(280, now);
        osc.frequency.exponentialRampToValueAtTime(60, now + 0.2);
        gain.gain.setValueAtTime(0.25, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.26);
      } else if (type === 'wrong') {
        // Dissonant buzz
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(140, now);
        osc.frequency.setValueAtTime(110, now + 0.1);
        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.26);
      } else if (type === 'playerDamage') {
        // Heavy blunt hit
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'square';
        osc.frequency.setValueAtTime(90, now);
        osc.frequency.exponentialRampToValueAtTime(40, now + 0.3);
        gain.gain.setValueAtTime(0.22, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.32);
      } else if (type === 'timeout') {
        // Whoosh / timer expiration drop
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(220, now);
        osc.frequency.exponentialRampToValueAtTime(65, now + 0.35);
        gain.gain.setValueAtTime(0.18, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.35);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.36);
      } else if (type === 'win') {
        // Victory triad arpeggio
        const notes = [523.25, 659.25, 783.99, 1046.50]; // C, E, G, High C
        notes.forEach((freq, idx) => {
          const osc = this.audioCtx.createOscillator();
          const gain = this.audioCtx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + idx * 0.12);
          gain.gain.setValueAtTime(0.2, now + idx * 0.12);
          gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.12 + 0.4);
          osc.connect(gain);
          gain.connect(this.audioCtx.destination);
          osc.start(now + idx * 0.12);
          osc.stop(now + idx * 0.12 + 0.45);
        });
      } else if (type === 'lose') {
        // Defeat falling cadence
        const notes = [400, 340, 270, 180];
        notes.forEach((freq, idx) => {
          const osc = this.audioCtx.createOscillator();
          const gain = this.audioCtx.createGain();
          osc.type = 'sawtooth';
          osc.frequency.setValueAtTime(freq, now + idx * 0.16);
          gain.gain.setValueAtTime(0.18, now + idx * 0.16);
          gain.gain.exponentialRampToValueAtTime(0.01, now + idx * 0.16 + 0.3);
          osc.connect(gain);
          gain.connect(this.audioCtx.destination);
          osc.start(now + idx * 0.16);
          osc.stop(now + idx * 0.16 + 0.35);
        });
      }
    } catch (e) {
      console.warn('Audio playback error:', e);
    }
  }
}

const sounds = new SoundManager();

// ============================================================================
// 4. DOM ELEMENTS CACHE
// ============================================================================

const DOM = {
  appWrapper: document.getElementById('game-app'),
  dragonHpBar: document.getElementById('dragon-hp-bar'),
  dragonHpText: document.getElementById('dragon-hp-text'),
  dragonContainer: document.getElementById('dragon-container'),
  dragonFlame: document.getElementById('dragon-flame'),
  dragonFloating: document.getElementById('dragon-combat-floating'),

  playerHpBar: document.getElementById('player-hp-bar'),
  playerHpText: document.getElementById('player-hp-text'),
  playerFloating: document.getElementById('player-combat-floating'),
  streakCount: document.getElementById('streak-count'),

  timerBar: document.getElementById('timer-bar'),
  timerText: document.getElementById('timer-text'),
  targetLetter: document.getElementById('target-letter'),
  targetCard: document.getElementById('target-letter-card'),
  targetSubtext: document.getElementById('target-subtext'),
  optionsSection: document.getElementById('options-section'),
  keyboardStatusBox: document.getElementById('keyboard-status-box'),
  kbLastKeyText: document.getElementById('kb-last-key-text'),

  answerButtons: [
    document.getElementById('btn-0'),
    document.getElementById('btn-1'),
    document.getElementById('btn-2'),
    document.getElementById('btn-3')
  ],
  answerLetters: [
    document.getElementById('letter-0'),
    document.getElementById('letter-1'),
    document.getElementById('letter-2'),
    document.getElementById('letter-3')
  ],

  statScore: document.getElementById('stat-score'),
  statCorrect: document.getElementById('stat-correct'),
  statWrong: document.getElementById('stat-wrong'),
  statMissed: document.getElementById('stat-missed'),
  statReaction: document.getElementById('stat-reaction'),
  statAvgReaction: document.getElementById('stat-avg-reaction'),
  difficultyBadge: document.getElementById('difficulty-badge'),
  inputBadge: document.getElementById('input-badge'),

  // Modals & Stepper Controls
  modalStart: document.getElementById('modal-start'),
  modalEnd: document.getElementById('modal-end'),
  modalHelp: document.getElementById('modal-help'),
  stepPill1: document.getElementById('step-pill-1'),
  stepPill2: document.getElementById('step-pill-2'),
  setupStep1: document.getElementById('setup-step-1'),
  setupStep2: document.getElementById('setup-step-2'),
  btnGotoStep2: document.getElementById('btn-goto-step-2'),
  btnBackToStep1: document.getElementById('btn-back-to-step-1'),
  inputMethodBtns: document.querySelectorAll('.input-method-btn'),

  btnStartGame: document.getElementById('btn-start-game'),
  btnRestart: document.getElementById('btn-restart'),
  btnPlayAgain: document.getElementById('btn-play-again'),
  btnSoundToggle: document.getElementById('btn-sound-toggle'),
  soundIcon: document.getElementById('sound-icon'),
  btnHowToPlay: document.getElementById('btn-how-to-play'),
  btnCloseHelp: document.getElementById('btn-close-help'),
  diffBtns: document.querySelectorAll('.diff-btn'),
  toast: document.getElementById('game-toast'),

  // End modal fields
  endBadgeIcon: document.getElementById('end-badge-icon'),
  endTitle: document.getElementById('end-title'),
  endSubtitle: document.getElementById('end-subtitle'),
  endScore: document.getElementById('end-score'),
  endInputMethod: document.getElementById('end-input-method'),
  endAccuracy: document.getElementById('end-accuracy'),
  endRounds: document.getElementById('end-rounds'),
  endAvgSpeed: document.getElementById('end-avg-speed'),
  endBestSpeed: document.getElementById('end-best-speed'),
  endHighestDiff: document.getElementById('end-highest-diff')
};

// ============================================================================
// 5. CORE GAMEPLAY FUNCTIONS
// ============================================================================

let currentSetupStep = 1;

/**
 * Transitions between Step 1 (Difficulty) and Step 2 (Input Method) in the start modal.
 * @param {number} stepNum
 */
function goToSetupStep(stepNum) {
  currentSetupStep = stepNum;
  if (stepNum === 1) {
    DOM.setupStep1.style.display = 'block';
    DOM.setupStep2.style.display = 'none';
    DOM.stepPill1.classList.add('active');
    DOM.stepPill2.classList.remove('active');
  } else {
    DOM.setupStep1.style.display = 'none';
    DOM.setupStep2.style.display = 'block';
    DOM.stepPill1.classList.remove('active');
    DOM.stepPill2.classList.add('active');
  }
}

/**
 * Opens the setup modal and resets view to Step 1
 */
function openSetupModal() {
  goToSetupStep(1);
  DOM.modalStart.classList.add('active');
}

/**
 * Synchronizes the top badge, arena options visibility, and keyboard helper to current input method.
 */
function updateInputMethodUI() {
  const isKeyboard = gameState.inputMethod === 'Keyboard';
  if (DOM.inputBadge) {
    DOM.inputBadge.textContent = gameState.inputMethod;
    DOM.inputBadge.className = isKeyboard ? 'badge badge-keyboard' : 'badge badge-click';
  }

  if (isKeyboard) {
    DOM.optionsSection.style.display = 'none';
    DOM.keyboardStatusBox.style.display = 'flex';
    DOM.targetSubtext.textContent = 'Press the matching key [A-Z] on your keyboard';
    DOM.kbLastKeyText.textContent = '-';
    DOM.kbLastKeyText.parentElement.classList.remove('correct', 'wrong');
  } else {
    DOM.optionsSection.style.display = 'block';
    DOM.keyboardStatusBox.style.display = 'none';
    DOM.targetSubtext.textContent = 'Click the matching glyph below';
  }
}

/**
 * Initializes and starts a new game session.
 * Resets HP, scores, counters, reaction times, and launches the first round.
 */
function startGame() {
  sounds.initContext();

  // Reset core health
  gameState.playerHp = gameState.maxHp;
  gameState.dragonHp = gameState.maxHp;

  // Reset metrics
  gameState.score = 0;
  gameState.correctAnswers = 0;
  gameState.wrongAnswers = 0;
  gameState.missedAnswers = 0;
  gameState.totalRounds = 0;
  gameState.currentStreak = 0;
  gameState.consecutiveErrors = 0;

  // Reset reaction time data
  gameState.reactionTimes = [];
  gameState.lastReactionTime = 0;
  gameState.fastestReactionTime = Infinity;

  gameState.isGameOver = false;

  // Hide any open modals
  DOM.modalStart.classList.remove('active');
  DOM.modalEnd.classList.remove('active');
  DOM.modalHelp.classList.remove('active');

  // Update visuals to initial state
  updateInputMethodUI();
  updateHealthBars();
  updateStats();
  updateDifficultyUI();

  // Trigger first battle round
  showToast(`Battle started! [${gameState.currentDifficulty} • ${gameState.inputMethod} Mode]`);
  startRound();
}

/**
 * Prepares and begins an individual combat round.
 * Generates question letters, resets timer, and enables input controls.
 */
function startRound() {
  if (gameState.isGameOver) return;

  // Clear any existing timer loops
  clearRoundTimers();

  // Increment total round count
  gameState.totalRounds++;
  gameState.isRoundActive = true;

  // Generate target and 4 options based on difficulty
  const question = generateQuestion();
  gameState.currentTargetLetter = question.target;
  gameState.currentOptions = question.options;

  // Render target letter
  DOM.targetLetter.textContent = question.target;
  DOM.targetCard.classList.remove('damaged', 'active', 'correct', 'wrong');
  // Re-trigger letter entry pop animation
  void DOM.targetLetter.offsetWidth;
  DOM.targetLetter.style.animation = 'runePop 0.28s cubic-bezier(0.175, 0.885, 0.32, 1.275)';

  if (gameState.inputMethod === 'Click') {
    // CLICK MODE: Show 4 answer buttons
    DOM.optionsSection.style.display = 'block';
    DOM.keyboardStatusBox.style.display = 'none';
    DOM.answerButtons.forEach((btn, idx) => {
      btn.classList.remove('correct', 'wrong');
      btn.disabled = false;
      DOM.answerLetters[idx].textContent = question.options[idx];
    });
  } else {
    // KEYBOARD MODE: Do NOT show any answer buttons/options. Display only the target letter.
    DOM.optionsSection.style.display = 'none';
    DOM.keyboardStatusBox.style.display = 'flex';
    DOM.kbLastKeyText.textContent = '-';
    DOM.kbLastKeyText.parentElement.classList.remove('correct', 'wrong');
  }

  // Start round timer & record timestamp for reaction time tracking
  const config = DIFFICULTY_CONFIG[gameState.currentDifficulty];
  const durationMs = config.timerDurationMs;
  gameState.roundStartTime = performance.now();

  initRoundTimer(durationMs);
}

/**
 * Generates the target letter and 3 distractors based on current difficulty.
 * - Easy: Completely random, distinct letters
 * - Medium: Distractors pulled from similar visual/confusing pools
 * - Hard: Distractors strictly pulled from high-confusion glyph clusters
 * 
 * @returns {{ target: string, options: string[] }}
 */
function generateQuestion() {
  // Pick random target letter A-Z
  const target = ALL_ALPHABET[Math.floor(Math.random() * ALL_ALPHABET.length)];
  const distractors = new Set();

  if (gameState.currentDifficulty === 'Hard') {
    // Look for confusing clusters that contain this target
    const matchedCluster = CONFUSING_LETTER_CLUSTERS.find(cluster => cluster.includes(target));
    if (matchedCluster) {
      // Pick other letters from the matched confusion cluster
      const candidates = matchedCluster.filter(char => char !== target);
      // Shuffle candidates
      const shuffledCandidates = [...candidates].sort(() => Math.random() - 0.5);
      for (const char of shuffledCandidates) {
        if (distractors.size < 3) {
          distractors.add(char);
        }
      }
    }
  } else if (gameState.currentDifficulty === 'Medium') {
    // Mix one confusing letter and two random letters
    const matchedCluster = CONFUSING_LETTER_CLUSTERS.find(cluster => cluster.includes(target));
    if (matchedCluster) {
      const candidates = matchedCluster.filter(char => char !== target);
      if (candidates.length > 0) {
        distractors.add(candidates[Math.floor(Math.random() * candidates.length)]);
      }
    }
  }

  // Fill remaining slots with distinct random letters
  while (distractors.size < 3) {
    const randomChar = ALL_ALPHABET[Math.floor(Math.random() * ALL_ALPHABET.length)];
    if (randomChar !== target) {
      distractors.add(randomChar);
    }
  }

  // Combine target with distractors and shuffle 4 options
  const options = [target, ...Array.from(distractors)];
  for (let i = options.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [options[i], options[j]] = [options[j], options[i]];
  }

  return { target, options };
}

/**
 * Handles the player's answer (via button click or direct keyboard press).
 * Validates match, updates scores, tracks reaction time, and triggers combat feedback.
 * 
 * @param {string} selectedLetter - The letter selected by the player
 * @param {HTMLButtonElement | null} buttonElement - The button element if clicked, or null if keyboard pressed
 */
function handleAnswer(selectedLetter, buttonElement) {
  if (!gameState.isRoundActive || gameState.isGameOver) return;

  // Immediately lock round input to prevent multiple answers
  gameState.isRoundActive = false;
  clearRoundTimers();

  // Calculate reaction time in milliseconds
  const reactionTime = Math.round(performance.now() - gameState.roundStartTime);
  gameState.lastReactionTime = reactionTime;
  gameState.reactionTimes.push(reactionTime);
  if (reactionTime < gameState.fastestReactionTime) {
    gameState.fastestReactionTime = reactionTime;
  }

  const isCorrect = selectedLetter === gameState.currentTargetLetter;
  const config = DIFFICULTY_CONFIG[gameState.currentDifficulty];

  // Disable all answer buttons during feedback phase (in Click mode)
  if (gameState.inputMethod === 'Click') {
    DOM.answerButtons.forEach(btn => { btn.disabled = true; });
  }

  // Visual feedback for Keyboard mode helper
  if (gameState.inputMethod === 'Keyboard') {
    DOM.kbLastKeyText.textContent = selectedLetter;
    const keyBox = DOM.kbLastKeyText.parentElement;
    keyBox.classList.remove('correct', 'wrong');
    void keyBox.offsetWidth;
    keyBox.classList.add(isCorrect ? 'correct' : 'wrong');
  }

  if (isCorrect) {
    // -------------------------------------------------------------
    // SUCCESS: Player hits Dragon
    // -------------------------------------------------------------
    gameState.correctAnswers++;
    gameState.currentStreak++;
    gameState.consecutiveErrors = 0;

    // Calculate score: Base score + speed bonus based on remaining time
    const timeRemainingRatio = Math.max(0, (config.timerDurationMs - reactionTime) / config.timerDurationMs);
    const speedBonus = Math.round(timeRemainingRatio * config.speedBonusMax);
    const roundScore = config.scoreBase + speedBonus;
    gameState.score += roundScore;

    // Damage dragon
    gameState.dragonHp = Math.max(0, gameState.dragonHp - config.damageToDragon);

    // Visual feedback
    if (buttonElement) {
      buttonElement.classList.add('correct');
    }
    DOM.targetCard.classList.add('correct');
    sounds.play('correct');

    // Visual dragon damage effects
    animateDragonHit(config.damageToDragon, roundScore);

    // Dynamic streak feedback
    adjustDifficulty();

  } else {
    // -------------------------------------------------------------
    // FAILURE: Player missed the glyph, Dragon retaliates
    // -------------------------------------------------------------
    gameState.wrongAnswers++;
    gameState.currentStreak = 0;
    gameState.consecutiveErrors++;

    // Damage player
    gameState.playerHp = Math.max(0, gameState.playerHp - config.damageToPlayer);

    // Visual feedback
    if (buttonElement) {
      buttonElement.classList.add('wrong');
      // Highlight the correct answer button to support learning
      const correctIdx = gameState.currentOptions.indexOf(gameState.currentTargetLetter);
      if (correctIdx !== -1 && DOM.answerButtons[correctIdx]) {
        DOM.answerButtons[correctIdx].classList.add('correct');
      }
    }
    DOM.targetCard.classList.add('wrong');
    sounds.play('wrong');

    // Visual player damage effects & dragon attack animation
    animateDragonAttack();
    const damageLabel = gameState.inputMethod === 'Keyboard'
      ? `-${config.damageToPlayer} HP [${selectedLetter} ✗]`
      : undefined;
    animatePlayerDamage(config.damageToPlayer, damageLabel);

    adjustDifficulty();
  }

  // Synchronize health bars and stats UI
  updateHealthBars();
  updateStats();

  // Check victory / defeat conditions
  if (gameState.dragonHp <= 0) {
    setTimeout(() => endGame(true), 600);
  } else if (gameState.playerHp <= 0) {
    setTimeout(() => endGame(false), 600);
  } else {
    // Transition to next round after brief feedback display
    setTimeout(() => {
      startRound();
    }, 850);
  }
}

/**
 * Handles round timer expiration when player does not select an answer in time.
 * Penalizes player HP, counts as missed, and advances round.
 */
function onTimerExpire() {
  if (!gameState.isRoundActive || gameState.isGameOver) return;

  gameState.isRoundActive = false;
  clearRoundTimers();

  const config = DIFFICULTY_CONFIG[gameState.currentDifficulty];

  // Record stats
  gameState.missedAnswers++;
  gameState.currentStreak = 0;
  gameState.consecutiveErrors++;

  // Penalize player HP
  gameState.playerHp = Math.max(0, gameState.playerHp - config.damageToPlayer);

  // Disable buttons and reveal correct answer in Click mode
  if (gameState.inputMethod === 'Click') {
    DOM.answerButtons.forEach(btn => { btn.disabled = true; });
    const correctIdx = gameState.currentOptions.indexOf(gameState.currentTargetLetter);
    if (correctIdx !== -1 && DOM.answerButtons[correctIdx]) {
      DOM.answerButtons[correctIdx].classList.add('correct');
    }
  }

  DOM.targetCard.classList.add('damaged');
  if (gameState.inputMethod === 'Keyboard') {
    DOM.kbLastKeyText.textContent = '⌛';
    DOM.kbLastKeyText.parentElement.classList.add('wrong');
  }

  sounds.play('timeout');

  // Trigger attack animations
  animateDragonAttack();
  animatePlayerDamage(config.damageToPlayer, 'TIMEOUT!');

  adjustDifficulty();

  // Synchronize UI
  updateHealthBars();
  updateStats();

  // Check game over
  if (gameState.playerHp <= 0) {
    setTimeout(() => endGame(false), 700);
  } else {
    setTimeout(() => {
      startRound();
    }, 1000);
  }
}

/**
 * Updates the health bar widths, color classes, and numeric text labels.
 */
function updateHealthBars() {
  // Dragon Health
  const dragonPercent = Math.max(0, Math.min(100, (gameState.dragonHp / gameState.maxHp) * 100));
  DOM.dragonHpBar.style.width = `${dragonPercent}%`;
  DOM.dragonHpText.textContent = `${gameState.dragonHp} / ${gameState.maxHp}`;

  // Adjust health color thresholds
  DOM.dragonHpBar.classList.remove('warning', 'danger');
  if (dragonPercent <= 25) {
    DOM.dragonHpBar.classList.add('danger');
  } else if (dragonPercent <= 50) {
    DOM.dragonHpBar.classList.add('warning');
  }

  // Player Health
  const playerPercent = Math.max(0, Math.min(100, (gameState.playerHp / gameState.maxHp) * 100));
  DOM.playerHpBar.style.width = `${playerPercent}%`;
  DOM.playerHpText.textContent = `${gameState.playerHp} / ${gameState.maxHp}`;

  DOM.playerHpBar.classList.remove('warning', 'danger');
  if (playerPercent <= 25) {
    DOM.playerHpBar.classList.add('danger');
  } else if (playerPercent <= 50) {
    DOM.playerHpBar.classList.add('warning');
  }
}

/**
 * Updates all numerical statistics on the game interface:
 * Score, Accuracy numbers, Streak, and Reaction Times.
 */
function updateStats() {
  DOM.statScore.textContent = gameState.score.toLocaleString();
  DOM.statCorrect.textContent = gameState.correctAnswers;
  DOM.statWrong.textContent = gameState.wrongAnswers;
  DOM.statMissed.textContent = gameState.missedAnswers;
  DOM.streakCount.textContent = gameState.currentStreak;

  // Last Reaction Time
  if (gameState.lastReactionTime > 0) {
    DOM.statReaction.textContent = `${gameState.lastReactionTime} ms`;
  } else {
    DOM.statReaction.textContent = '-- ms';
  }

  // Average Reaction Time
  if (gameState.reactionTimes.length > 0) {
    const totalTime = gameState.reactionTimes.reduce((acc, curr) => acc + curr, 0);
    const avg = Math.round(totalTime / gameState.reactionTimes.length);
    DOM.statAvgReaction.textContent = `${avg} ms`;
  } else {
    DOM.statAvgReaction.textContent = '-- ms';
  }
}

/**
 * Cognitive streak feedback:
 * The selected difficulty remains active for the entire game session as chosen by the player.
 * We provide dynamic cognitive streak encouragement to motivate the player.
 */
function adjustDifficulty() {
  if (gameState.currentStreak >= 3 && gameState.currentStreak % 3 === 0) {
    showToast(`🔥 Cognitive Surge! ${gameState.currentStreak} correct streak!`);
  }
}

/**
 * Sets the current difficulty and tracks the highest level reached
 * @param {'Easy' | 'Medium' | 'Hard'} newDiff
 */
function setDifficulty(newDiff) {
  gameState.currentDifficulty = newDiff;
  const ranks = { Easy: 1, Medium: 2, Hard: 3 };
  if (ranks[newDiff] > ranks[gameState.highestDifficultyReached]) {
    gameState.highestDifficultyReached = newDiff;
  }
}

/**
 * Updates the difficulty badge style in the navigation bar
 */
function updateDifficultyUI() {
  const badge = DOM.difficultyBadge;
  badge.textContent = gameState.currentDifficulty;
  badge.className = `badge badge-${gameState.currentDifficulty.toLowerCase()}`;
}

/**
 * Concludes the game session and presents the Victory or Defeat summary screen.
 * @param {boolean} isWin - Whether the player defeated the dragon
 */
function endGame(isWin) {
  gameState.isGameOver = true;
  gameState.isRoundActive = false;
  clearRoundTimers();

  // Calculate summary metrics
  const totalAttempts = gameState.correctAnswers + gameState.wrongAnswers + gameState.missedAnswers;
  const accuracy = totalAttempts > 0 ? Math.round((gameState.correctAnswers / totalAttempts) * 100) : 0;
  
  let avgReaction = 0;
  if (gameState.reactionTimes.length > 0) {
    const totalReaction = gameState.reactionTimes.reduce((acc, curr) => acc + curr, 0);
    avgReaction = Math.round(totalReaction / gameState.reactionTimes.length);
  }
  const bestReaction = gameState.fastestReactionTime !== Infinity ? gameState.fastestReactionTime : 0;

  // Populate End Modal UI
  DOM.endScore.textContent = gameState.score.toLocaleString();
  if (DOM.endInputMethod) {
    DOM.endInputMethod.textContent = gameState.inputMethod;
  }
  DOM.endAccuracy.textContent = `${accuracy}% (${gameState.correctAnswers}/${totalAttempts})`;
  DOM.endRounds.textContent = gameState.totalRounds;
  DOM.endAvgSpeed.textContent = avgReaction > 0 ? `${avgReaction} ms` : 'N/A';
  DOM.endBestSpeed.textContent = bestReaction > 0 ? `${bestReaction} ms` : 'N/A';
  DOM.endHighestDiff.textContent = gameState.highestDifficultyReached;

  if (isWin) {
    DOM.endBadgeIcon.textContent = '🏆';
    DOM.endTitle.textContent = 'VICTORY! DRAGON SLAIN!';
    DOM.endTitle.className = 'modal-title highlight-gold';
    DOM.endSubtitle.textContent = 'Superb reaction speed! You conquered the cognitive wyrm with precision.';
    sounds.play('win');
  } else {
    DOM.endBadgeIcon.textContent = '💀';
    DOM.endTitle.textContent = 'DEFEAT! RUNES EXHAUSTED';
    DOM.endTitle.className = 'modal-title text-red';
    DOM.endSubtitle.textContent = 'The dragon overwhelmed your defenses. Train your reflexes and try again!';
    sounds.play('lose');
  }

  // Show end modal
  DOM.modalEnd.classList.add('active');
}

// ============================================================================
// 6. ANIMATIONS & VISUAL FEEDBACK
// ============================================================================

/**
 * Runs countdown timer bar and text display with 30fps animation tick.
 * @param {number} totalDurationMs
 */
function initRoundTimer(totalDurationMs) {
  DOM.timerBar.style.width = '100%';
  DOM.timerBar.classList.remove('urgent');

  const startStamp = performance.now();

  roundTimerInterval = setInterval(() => {
    const elapsed = performance.now() - startStamp;
    const remaining = Math.max(0, totalDurationMs - elapsed);
    const progress = (remaining / totalDurationMs) * 100;

    DOM.timerBar.style.width = `${progress}%`;
    DOM.timerText.textContent = `${(remaining / 1000).toFixed(2)}s`;

    // Red warning pulse when under 30% of total time
    if (progress < 30) {
      DOM.timerBar.classList.add('urgent');
    }
  }, 33);

  roundTimerTimeout = setTimeout(() => {
    clearInterval(roundTimerInterval);
    DOM.timerBar.style.width = '0%';
    DOM.timerText.textContent = '0.00s';
    onTimerExpire();
  }, totalDurationMs);
}

/**
 * Clears active round timers
 */
function clearRoundTimers() {
  if (roundTimerTimeout) {
    clearTimeout(roundTimerTimeout);
    roundTimerTimeout = null;
  }
  if (roundTimerInterval) {
    clearInterval(roundTimerInterval);
    roundTimerInterval = null;
  }
}

/**
 * Triggers dragon damage animation and floating combat text
 * @param {number} hpDamage
 * @param {number} pointsGained
 */
function animateDragonHit(hpDamage, pointsGained) {
  // Shake dragon sprite
  DOM.dragonContainer.classList.remove('damage', 'attack');
  void DOM.dragonContainer.offsetWidth; // Reflow
  DOM.dragonContainer.classList.add('damage');

  sounds.play('hit');

  // Floating damage number
  createFloatingText(DOM.dragonFloating, `-${hpDamage} HP`, 'combat-float-damage');
  createFloatingText(DOM.dragonFloating, `+${pointsGained} PTS`, 'combat-float-score');

  setTimeout(() => {
    DOM.dragonContainer.classList.remove('damage');
  }, 450);
}

/**
 * Triggers dragon attack lunge and flame effect
 */
function animateDragonAttack() {
  DOM.dragonContainer.classList.remove('damage', 'attack');
  void DOM.dragonContainer.offsetWidth;
  DOM.dragonContainer.classList.add('attack');

  DOM.dragonFlame.classList.add('active');

  setTimeout(() => {
    DOM.dragonContainer.classList.remove('attack');
    DOM.dragonFlame.classList.remove('active');
  }, 500);
}

/**
 * Triggers player damage shake and red border flash
 * @param {number} hpDamage
 * @param {string} [customLabel]
 */
function animatePlayerDamage(hpDamage, customLabel) {
  // Screen impact shake
  DOM.appWrapper.classList.remove('screen-shake');
  void DOM.appWrapper.offsetWidth;
  DOM.appWrapper.classList.add('screen-shake');

  sounds.play('playerDamage');

  // Floating damage on player area
  const label = customLabel || `-${hpDamage} HP`;
  createFloatingText(DOM.playerFloating, label, 'combat-float-damage');

  setTimeout(() => {
    DOM.appWrapper.classList.remove('screen-shake');
  }, 400);
}

/**
 * Spawns a floating feedback label that moves upward and fades out
 * @param {HTMLElement} container
 * @param {string} text
 * @param {string} className
 */
function createFloatingText(container, text, className) {
  if (!container) return;
  const floatEl = document.createElement('div');
  floatEl.className = `combat-float-item ${className}`;
  floatEl.textContent = text;
  container.appendChild(floatEl);

  setTimeout(() => {
    if (floatEl.parentNode) {
      floatEl.parentNode.removeChild(floatEl);
    }
  }, 900);
}

/**
 * Shows temporary status toast message
 * @param {string} message
 */
function showToast(message) {
  DOM.toast.textContent = message;
  DOM.toast.classList.add('show');
  setTimeout(() => {
    DOM.toast.classList.remove('show');
  }, 2200);
}

// ============================================================================
// 7. EVENT LISTENERS & KEYBOARD CONTROLS
// ============================================================================

/**
 * Attach button click handlers
 */
function setupEventListeners() {
  // Answer buttons click (Click Mode)
  DOM.answerButtons.forEach((btn, index) => {
    btn.addEventListener('click', () => {
      if (gameState.inputMethod !== 'Click') return;
      const selectedLetter = DOM.answerLetters[index].textContent;
      handleAnswer(selectedLetter, btn);
    });
  });

  // Stepper flow navigation in Start Modal
  if (DOM.btnGotoStep2) {
    DOM.btnGotoStep2.addEventListener('click', () => {
      goToSetupStep(2);
    });
  }

  if (DOM.btnBackToStep1) {
    DOM.btnBackToStep1.addEventListener('click', () => {
      goToSetupStep(1);
    });
  }

  // Input Method Selector (Step 2)
  DOM.inputMethodBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      DOM.inputMethodBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const selectedMethod = btn.getAttribute('data-input-method');
      if (selectedMethod) {
        gameState.inputMethod = selectedMethod;
      }
    });
  });

  // Global Keyboard event handler
  window.addEventListener('keydown', (e) => {
    // 1. Navigation when Start Modal is active
    if (DOM.modalStart.classList.contains('active')) {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (currentSetupStep === 1) {
          goToSetupStep(2);
        } else {
          startGame();
        }
      } else if (e.key === 'Escape' && currentSetupStep === 2) {
        goToSetupStep(1);
      }
      return;
    }

    // 2. Navigation when End Modal is active
    if (DOM.modalEnd.classList.contains('active')) {
      if (e.key === 'Enter') {
        e.preventDefault();
        openSetupModal();
      }
      return;
    }

    // 3. Navigation when Help Modal is active
    if (DOM.modalHelp.classList.contains('active')) {
      if (e.key === 'Enter' || e.key === 'Escape') {
        DOM.modalHelp.classList.remove('active');
      }
      return;
    }

    // 4. ACCIDENTAL KEYPRESS PREVENTION:
    // Prevent accidental key presses from causing problems when the game is not running
    if (!gameState.isRoundActive || gameState.isGameOver) return;

    // 5. KEYBOARD MODE:
    // Display only the target letter. Player must press the corresponding keyboard key.
    // Ignore unrelated keys (Shift, Alt, Ctrl, Enter, Arrow keys, etc.)
    if (gameState.inputMethod === 'Keyboard') {
      if (e.key.length === 1 && /^[a-zA-Z]$/.test(e.key)) {
        e.preventDefault();
        const pressedLetter = e.key.toUpperCase();
        handleAnswer(pressedLetter, null);
      }
      // Non-alphabet keys (Shift, Caps, Arrow, Space, etc.) are strictly ignored
      return;
    }

    // 6. CLICK MODE:
    // Number keys 1-4 can trigger button clicks
    if (gameState.inputMethod === 'Click') {
      if (['1', '2', '3', '4'].includes(e.key)) {
        const idx = parseInt(e.key, 10) - 1;
        if (DOM.answerButtons[idx] && !DOM.answerButtons[idx].disabled) {
          DOM.answerButtons[idx].click();
        }
      }
    }
  });

  // Start Game Button in Modal Step 2
  DOM.btnStartGame.addEventListener('click', startGame);

  // Restart Button in Battle View opens setup modal
  DOM.btnRestart.addEventListener('click', openSetupModal);

  // Play Again Button in End Modal opens setup modal
  DOM.btnPlayAgain.addEventListener('click', openSetupModal);

  // Difficulty selector in Start Modal Step 1
  DOM.diffBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      DOM.diffBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const selectedDiff = btn.getAttribute('data-diff');
      setDifficulty(selectedDiff);
      updateDifficultyUI();
    });
  });

  // Sound Toggle
  DOM.btnSoundToggle.addEventListener('click', () => {
    gameState.isSoundMuted = !gameState.isSoundMuted;
    DOM.soundIcon.textContent = gameState.isSoundMuted ? '🔇' : '🔊';
    showToast(gameState.isSoundMuted ? 'Sound Muted' : 'Sound Enabled');
  });

  // Help Modal Toggle
  DOM.btnHowToPlay.addEventListener('click', () => {
    DOM.modalHelp.classList.add('active');
  });

  DOM.btnCloseHelp.addEventListener('click', () => {
    DOM.modalHelp.classList.remove('active');
  });
}

// ============================================================================
// 8. INITIALIZATION
// ============================================================================

// Initialize on DOM load
document.addEventListener('DOMContentLoaded', () => {
  setupEventListeners();
  updateDifficultyUI();
  updateInputMethodUI();
  updateHealthBars();
  updateStats();
});
